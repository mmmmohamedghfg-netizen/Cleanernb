package com.smartcleaner.pro

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * خدمة الجدولة التلقائية في الخلفية (v6.0 - Audited)
 * الإصلاحات الجذرية المطبقة:
 * 1. إلغاء آمن لـ CoroutineScope و Active Job عند استدعاء onStopJob أو onDestroy لمنع تسريب الخيوط (Coroutine Leak).
 * 2. التحقق من صلاحية POST_NOTIFICATIONS على Android 13+ قبل إرسال الإشعار لتفادي SecurityException.
 * 3. ضبط android:exported="false" في AndroidManifest.xml لحماية الخدمة من الاستدعاء الخارجي غير المصرح به.
 */
class AutoCleanJobService : JobService() {

    private val jobScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var activeCleanJob: Job? = null

    override fun onStartJob(params: JobParameters?): Boolean {
        activeCleanJob = jobScope.launch {
            try {
                val whitelist = SafetyAndVaultManager.getWhitelistedPaths(applicationContext)
                val cacheDirs = mutableListOf<File>()
                cacheDir?.let { cacheDirs.add(it) }
                externalCacheDir?.let { cacheDirs.add(it) }

                val scanned = CleanerEngine.performFullScan(
                    appCacheDirs = cacheDirs,
                    whitelist = whitelist,
                    onProgress = {}
                )

                val autoCleanTargets = scanned.filter {
                    it.category in setOf(
                        CleanCategory.RECENTLY_DELETED,
                        CleanCategory.JUNK_TEMP,
                        CleanCategory.EMPTY_FOLDERS,
                        CleanCategory.HIDDEN_USELESS
                    ) && it.aiSafetyScore >= 90
                }

                if (autoCleanTargets.isNotEmpty()) {
                    val (deletedCount, freedBytes) = CleanerEngine.deleteSelectedItems(
                        context = applicationContext,
                        items = autoCleanTargets,
                        useQuarantine = SafetyAndVaultManager.isQuarantineEnabled(applicationContext),
                        onProgress = {}
                    )
                    if (deletedCount > 0) {
                        sendAutoCleanNotification(deletedCount, freedBytes)
                    }
                }
            } catch (_: Exception) {
            } finally {
                jobFinished(params, false)
            }
        }
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        activeCleanJob?.cancel()
        return true
    }

    override fun onDestroy() {
        activeCleanJob?.cancel()
        jobScope.cancel()
        super.onDestroy()
    }

    private fun sendAutoCleanNotification(deletedCount: Int, freedBytes: Long) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val channelId = "smart_cleaner_auto_channel"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "التنظيف الذكي التلقائي",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            nm.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_delete)
            .setContentTitle("المنظف الذكي AI أكمل الصيانة التلقائية ✨")
            .setContentText("تم حذف $deletedCount ملف مؤقت وتوفير ${CleanerEngine.formatSize(freedBytes)} في الخلفية.")
            .setAutoCancel(true)
            .build()

        nm.notify(4001, notification)
    }

    companion object {
        private const val JOB_ID = 9042

        fun schedulePeriodicAutoClean(context: Context, enable: Boolean) {
            val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            if (!enable) {
                scheduler.cancel(JOB_ID)
                SafetyAndVaultManager.setAutoCleanEnabled(context, false)
                return
            }

            val component = ComponentName(context, AutoCleanJobService::class.java)
            val jobInfo = JobInfo.Builder(JOB_ID, component)
                .setPeriodic(24L * 60L * 60L * 1000L)
                .setPersisted(true)
                .setRequiresBatteryNotLow(true)
                .build()

            scheduler.schedule(jobInfo)
            SafetyAndVaultManager.setAutoCleanEnabled(context, true)
        }
    }
}
