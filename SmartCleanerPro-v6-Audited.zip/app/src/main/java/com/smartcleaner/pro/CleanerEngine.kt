package com.smartcleaner.pro

import android.content.Context
import android.os.Environment
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

enum class CleanCategory(
    val titleAr: String,
    val subtitleAr: String,
    val badgeColorHex: Long
) {
    COMPRESSIBLE_MEDIA_AI(
        "ضغط الصور والفيديوهات بالـ AI (بدون حذف)",
        "تقليل حجم الصور والفيديوهات الكبيرة بنسبة 45% إلى 80% مع بقائها محفوظة في المعرض",
        0xFF00E676
    ),
    SIMILAR_PHOTOS_AI(
        "الصور المتشابهة بصرياً (AI dHash)",
        "كشف اللقطات المتكررة لنفس المشهد بالبصمة البصرية 64-bit مع حفظ اللقطة الأوضح تلقائياً",
        0xFF18FFFF
    ),
    DUPLICATES_AI(
        "الملفات المكررة بالبصمة الجزيئية (SHA-256)",
        "نسخ متطابقة 100% في المحتوى مع الاحتفاظ بالملف الأصلي تلقائياً",
        0xFFE040FB
    ),
    RECENTLY_DELETED(
        "المحذوف مؤخراً وسلة المهملات",
        "بقايا الصور والفيديوهات المحذوفة ومجلدات .Trash و .trashed",
        0xFFFF5252
    ),
    HIDDEN_USELESS(
        "الملفات المخفية غير الضرورية",
        "ملفات .thumbdata العملاقة والصور المصغرة المخفية والملفات التالفة صفرية الإنتروبيا",
        0xFFFFAB40
    ),
    SCREENSHOTS_VOICE_AI(
        "لقطات الشاشة والريكوردات القديمة (AI)",
        "فرز ذكي للقطات الشاشة القديمة والمقاطع الصوتية المتراكمة",
        0xFFFF4081
    ),
    MESSENGER_RESIDUAL_AI(
        "مخلفات تطبيقات الدردشة (AI)",
        "نسخ الرسائل المرسلة (Sent) والحالات المؤقتة القديمة في واتساب وتليجرام",
        0xFF00E5FF
    ),
    BAD_IMAGES_AI(
        "الصور التالفة أو المظلمة بالخطأ (AI Vision)",
        "تحليل بصري محلي للصور السوداء تماماً أو المشوشة أو المعطوبة",
        0xFFFF6E40
    ),
    JUNK_TEMP(
        "مخلفات النظام والملفات المؤقتة",
        "ملفات .tmp و .log و .bak ومخلفات التثبيت APK القديمة",
        0xFF00B0FF
    ),
    EMPTY_FOLDERS(
        "المجلدات الفارغة",
        "مجلدات مهجورة فارغة تماماً تسبب فوضى في الذاكرة",
        0xFF7C4DFF
    ),
    LARGE_FILES(
        "الملفات الضخمة (+25 ميجابايت)",
        "ملفات كبيرة الحجم تستهلك المساحة (تُترك بدون تحديد تلقائي للأمان)",
        0xFFFFD740
    )
}

data class ScannedItem(
    val file: File,
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val category: CleanCategory,
    val isDirectory: Boolean,
    val aiSafetyScore: Int = 90,
    val aiReasonAr: String = "",
    val estimatedCompressionSavingsBytes: Long = 0L,
    val isSelected: Boolean = category != CleanCategory.LARGE_FILES && category != CleanCategory.COMPRESSIBLE_MEDIA_AI
)

data class StorageStats(
    val totalBytes: Long = 0L,
    val usedBytes: Long = 0L,
    val freeBytes: Long = 0L
) {
    val usedRatio: Float
        get() = if (totalBytes > 0) (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

/**
 * محرك الفحص والحذف الرئيسي (v6.0 - Audited)
 * الإصلاحات الجذرية المطبقة:
 * 1. تتبع المسارات القانونية (visitedCanonicalDirs via file.canonicalPath) لمنع الحلقات اللانهائية الناتجة عن الروابط الرمزية (Symlink Loops).
 * 2. استثناء الملفات المؤقتة للضغط (.ai_tmp_*, .ai_bak_*, .ai_vid_*) من الفحص حتى لا يتم حذف ملف قيد المعالجة.
 */
object CleanerEngine {

    fun getStorageStats(): StorageStats {
        return try {
            val path = Environment.getExternalStorageDirectory()
            val stat = StatFs(path.path)
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val availableBlocks = stat.availableBlocksLong

            val total = totalBlocks * blockSize
            val free = availableBlocks * blockSize
            val used = (total - free).coerceAtLeast(0L)
            StorageStats(totalBytes = total, usedBytes = used, freeBytes = free)
        } catch (e: Exception) {
            StorageStats()
        }
    }

    fun formatSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unitIndex = 0
        while (value >= 1024 && unitIndex < units.size - 1) {
            value /= 1024.0
            unitIndex++
        }
        return String.format(Locale.US, "%.2f %s", value, units[unitIndex])
    }

    private val trashDirNames = setOf(
        ".trash", ".trashes", ".recycle", ".recyclebin", ".globaltrash",
        ".deleted", "trash", "recyclebin"
    )

    private val hiddenUselessDirNames = setOf(
        ".thumbnails", ".cache", ".temp", ".tmp", ".exo", ".preload"
    )

    private val junkExtensions = setOf(
        "tmp", "temp", "log", "bak", "old", "dmp", "crdownload", "part", "apk"
    )

    suspend fun performFullScan(
        appCacheDirs: List<File>,
        whitelist: Set<String> = emptySet(),
        onProgress: (String) -> Unit
    ): List<ScannedItem> = withContext(Dispatchers.IO) {
        val results = mutableListOf<ScannedItem>()
        val seenPaths = HashSet<String>()
        val visitedCanonicalDirs = HashSet<String>()
        val candidateFilesForDuplicateCheck = mutableListOf<File>()
        val candidatePhotosForDHashCheck = mutableListOf<File>()

        fun addItem(
            file: File,
            category: CleanCategory,
            customSize: Long? = null,
            customReason: String? = null,
            compressionSavings: Long = 0L
        ) {
            val absPath = file.absolutePath
            if (SafetyAndVaultManager.isPathWhitelisted(absPath, whitelist)) return
            if (absPath.contains(".SmartCleanerVault")) return

            if (seenPaths.add(absPath)) {
                val size = customSize ?: if (file.isDirectory) computeDirSize(file) else file.length()
                val aiEval = AiOfflineBrain.evaluateFile(file, category)
                results.add(
                    ScannedItem(
                        file = file,
                        name = file.name.ifEmpty { absPath },
                        path = absPath,
                        sizeBytes = size,
                        category = category,
                        isDirectory = file.isDirectory,
                        aiSafetyScore = aiEval.safetyScore,
                        aiReasonAr = customReason ?: aiEval.aiReasonAr,
                        estimatedCompressionSavingsBytes = compressionSavings,
                        isSelected = category != CleanCategory.LARGE_FILES &&
                            category != CleanCategory.COMPRESSIBLE_MEDIA_AI &&
                            aiEval.safetyScore >= 80
                    )
                )
            }
        }

        appCacheDirs.forEach { cacheDir ->
            if (cacheDir.exists() && cacheDir.canRead()) {
                cacheDir.listFiles()?.forEach { child ->
                    if (!child.name.contains("SmartCleanerVault")) {
                        onProgress("تحليل الكاش بالـ AI: ${child.name}")
                        addItem(child, CleanCategory.JUNK_TEMP)
                    }
                }
            }
        }

        val root = Environment.getExternalStorageDirectory()
        if (!root.exists() || !root.canRead()) {
            return@withContext results
        }

        fun scanRecursive(dir: File, depth: Int) {
            if (depth > 8) return
            if (SafetyAndVaultManager.isPathWhitelisted(dir.absolutePath, whitelist)) return

            val canonical = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
            if (!visitedCanonicalDirs.add(canonical)) return

            val children = try {
                dir.listFiles()
            } catch (e: Exception) {
                null
            } ?: return

            if (children.isEmpty() && depth > 1) {
                addItem(dir, CleanCategory.EMPTY_FOLDERS, 0L)
                return
            }

            for (child in children) {
                val name = child.name
                val lowerName = name.lowercase(Locale.ROOT)
                val absPath = child.absolutePath
                val lowerPath = absPath.lowercase(Locale.ROOT)

                if (SafetyAndVaultManager.isPathWhitelisted(absPath, whitelist)) continue
                if (name == ".SmartCleanerVault" ||
                    lowerName.startsWith(".ai_tmp_") ||
                    lowerName.startsWith(".ai_bak_") ||
                    lowerName.startsWith(".ai_vid_")
                ) continue

                if (depth == 1 && lowerName == "android") {
                    val mediaDir = File(child, "media")
                    if (mediaDir.exists() && mediaDir.canRead()) {
                        scanRecursive(mediaDir, depth + 1)
                    }
                    continue
                }

                onProgress("الفحص الذكي (AI): $name")

                if (child.isDirectory) {
                    if (lowerName in trashDirNames || lowerName.startsWith(".trash") || lowerName.contains("recycle")) {
                        val size = computeDirSize(child)
                        if (size > 0L || (child.listFiles()?.isNotEmpty() == true)) {
                            addItem(child, CleanCategory.RECENTLY_DELETED, size)
                        }
                        continue
                    }

                    if (lowerName in hiddenUselessDirNames) {
                        val size = computeDirSize(child)
                        if (size > 0L || (child.listFiles()?.isNotEmpty() == true)) {
                            addItem(child, CleanCategory.HIDDEN_USELESS, size)
                        }
                        continue
                    }

                    if (lowerName == ".statuses" ||
                        (lowerName == "sent" && (lowerPath.contains("whatsapp") || lowerPath.contains("telegram")))
                    ) {
                        val size = computeDirSize(child)
                        if (size > 0L) {
                            addItem(
                                child,
                                CleanCategory.MESSENGER_RESIDUAL_AI,
                                size,
                                "ثقة الذكاء الاصطناعي 94%: نسخ وسائط مرسلة/حالات مؤقتة مكررة في الدردشة"
                            )
                        }
                        continue
                    }

                    if (lowerName.startsWith(".") &&
                        (lowerName.contains("cache") || lowerName.contains("thumb") || lowerName.contains("temp") || lowerName.contains("tmp"))
                    ) {
                        val size = computeDirSize(child)
                        if (size > 0L) {
                            addItem(child, CleanCategory.HIDDEN_USELESS, size)
                        }
                        continue
                    }

                    scanRecursive(child, depth + 1)

                    val remaining = try { child.listFiles() } catch (_: Exception) { null }
                    if (remaining != null && remaining.isEmpty()) {
                        addItem(child, CleanCategory.EMPTY_FOLDERS, 0L)
                    }
                } else {
                    val fileSize = child.length()
                    val ext = child.extension.lowercase(Locale.ROOT)

                    if (lowerName.startsWith(".trashed-") ||
                        lowerName.startsWith(".pending-") ||
                        lowerPath.contains("/.trash")
                    ) {
                        addItem(child, CleanCategory.RECENTLY_DELETED, fileSize)
                        continue
                    }

                    if (lowerName.startsWith(".thumbdata") ||
                        (lowerName.startsWith(".") && lowerName != ".nomedia" && (
                            lowerName.endsWith(".tmp") ||
                                lowerName.endsWith(".log") ||
                                lowerName.endsWith(".cache") ||
                                lowerName.endsWith(".dat") ||
                                lowerName.endsWith(".db-shm") ||
                                lowerName.endsWith(".db-wal") ||
                                fileSize == 0L
                            ))
                    ) {
                        addItem(child, CleanCategory.HIDDEN_USELESS, fileSize)
                        continue
                    }

                    if (ext in junkExtensions || lowerName.endsWith(".temp") || lowerName.startsWith("~$")) {
                        addItem(child, CleanCategory.JUNK_TEMP, fileSize)
                        continue
                    }

                    val screenOrVoice = AiOfflineBrain.classifyScreenshotOrVoiceNote(child)
                    if (screenOrVoice != null && screenOrVoice.first) {
                        addItem(child, CleanCategory.SCREENSHOTS_VOICE_AI, fileSize, screenOrVoice.second)
                        continue
                    }

                    if (ext in setOf("jpg", "jpeg", "png") && fileSize in 4096L..(15L * 1024L * 1024L)) {
                        val visionCheck = AiOfflineBrain.analyzeImageQualityOffline(child)
                        if (visionCheck != null && visionCheck.first) {
                            addItem(
                                child,
                                CleanCategory.BAD_IMAGES_AI,
                                fileSize,
                                "رؤية الذكاء الاصطناعي المحلية: ${visionCheck.second}"
                            )
                            continue
                        }
                        if (candidatePhotosForDHashCheck.size < 220) {
                            candidatePhotosForDHashCheck.add(child)
                        }
                    }

                    if (fileSize >= 32L * 1024L) {
                        candidateFilesForDuplicateCheck.add(child)
                    }

                    if (AiMediaCompressor.isSupportedMedia(child)) {
                        val compAnalysis = AiMediaCompressor.analyzeMediaCompressibility(child)
                        if (compAnalysis.isCompressible && compAnalysis.estimatedSavedBytes > 200L * 1024L) {
                            addItem(
                                file = child,
                                category = CleanCategory.COMPRESSIBLE_MEDIA_AI,
                                customSize = fileSize,
                                customReason = compAnalysis.explanationAr,
                                compressionSavings = compAnalysis.estimatedSavedBytes
                            )
                            continue
                        }
                    }

                    if (fileSize >= 25L * 1024L * 1024L) {
                        addItem(child, CleanCategory.LARGE_FILES, fileSize)
                    }
                }
            }
        }

        scanRecursive(root, 1)

        onProgress("الذكاء الاصطناعي يطابق البصمة الجزيئية للملفات المكررة...")
        val sameSizeGroups = candidateFilesForDuplicateCheck
            .filter { it.exists() && it.isFile }
            .groupBy { it.length() }
            .filter { it.value.size > 1 }

        val exactDuplicatePaths = HashSet<String>()

        for ((sizeBytes, group) in sameSizeGroups) {
            val hashGroups = group.groupBy { AiOfflineBrain.computeFastContentFingerprint(it) }
            for ((hashKey, identicalFiles) in hashGroups) {
                if (hashKey != null && identicalFiles.size > 1) {
                    val sortedByAge = identicalFiles.sortedBy { it.lastModified() }
                    val originalFile = sortedByAge.first()
                    val duplicateCopies = sortedByAge.drop(1)

                    for (dup in duplicateCopies) {
                        exactDuplicatePaths.add(dup.absolutePath)
                        results.removeAll {
                            it.path == dup.absolutePath &&
                                (it.category == CleanCategory.LARGE_FILES || it.category == CleanCategory.COMPRESSIBLE_MEDIA_AI)
                        }
                        seenPaths.remove(dup.absolutePath)

                        addItem(
                            file = dup,
                            category = CleanCategory.DUPLICATES_AI,
                            customSize = sizeBytes,
                            customReason = "ثقة الذكاء الاصطناعي 96%: نسخة مكررة متطابقة البصمة مع (${originalFile.name}) المحفوظ بأمان"
                        )
                    }
                }
            }
        }

        onProgress("الـ AI يفحص الصور المتشابهة بصرياً عبر خوارزمية dHash 64-bit...")
        data class PhotoDHashEntry(val file: File, val dHash: Long, val sharpness: Double)

        val photoEntries = mutableListOf<PhotoDHashEntry>()
        for (photo in candidatePhotosForDHashCheck) {
            if (photo.absolutePath in exactDuplicatePaths) continue
            val dHash = AiOfflineBrain.computePerceptualDHash64(photo) ?: continue
            val sharpness = AiOfflineBrain.computeImageEdgeComplexity(photo)
            photoEntries.add(PhotoDHashEntry(photo, dHash, sharpness))
        }

        val visitedIndices = BooleanArray(photoEntries.size)
        for (i in photoEntries.indices) {
            if (visitedIndices[i]) continue
            val cluster = mutableListOf(photoEntries[i])
            visitedIndices[i] = true

            for (j in i + 1 until photoEntries.size) {
                if (visitedIndices[j]) continue
                val dist = AiOfflineBrain.hammingDistance64(photoEntries[i].dHash, photoEntries[j].dHash)
                if (dist <= 9) {
                    cluster.add(photoEntries[j])
                    visitedIndices[j] = true
                }
            }

            if (cluster.size > 1) {
                val sortedBySharpness = cluster.sortedByDescending { it.sharpness * 1000.0 + (it.file.length() / 1024.0) }
                val bestPhoto = sortedBySharpness.first()
                val inferiorShots = sortedBySharpness.drop(1)

                for (inf in inferiorShots) {
                    results.removeAll {
                        it.path == inf.file.absolutePath &&
                            it.category == CleanCategory.COMPRESSIBLE_MEDIA_AI
                    }
                    seenPaths.remove(inf.file.absolutePath)
                    addItem(
                        file = inf.file,
                        category = CleanCategory.SIMILAR_PHOTOS_AI,
                        customSize = inf.file.length(),
                        customReason = "بصمة بصرية dHash متشابهة: تم الاحتفاظ باللقطة الأوضح (${bestPhoto.file.name}) تلقائياً"
                    )
                }
            }
        }

        results.sortedByDescending { it.sizeBytes }
    }

    private fun computeDirSize(dir: File, maxDepth: Int = 5): Long {
        if (maxDepth <= 0) return 0L
        var total = 0L
        val files = try { dir.listFiles() } catch (_: Exception) { null } ?: return 0L
        for (f in files) {
            total += if (f.isDirectory) {
                computeDirSize(f, maxDepth - 1)
            } else {
                f.length()
            }
        }
        return total
    }

    suspend fun deleteSelectedItems(
        context: Context,
        items: List<ScannedItem>,
        useQuarantine: Boolean,
        onProgress: (String) -> Unit
    ): Pair<Int, Long> = withContext(Dispatchers.IO) {
        var deletedCount = 0
        var freedBytes = 0L

        for (item in items) {
            if (!item.isSelected) continue
            onProgress("جاري المعالجة: ${item.name}")
            val target = item.file
            if (target.exists()) {
                val ok = if (useQuarantine && !target.isDirectory) {
                    SafetyAndVaultManager.moveFileToQuarantine(context, target, item.sizeBytes)
                } else if (target.isDirectory) {
                    deleteDirectoryRecursively(target)
                } else {
                    try {
                        target.delete()
                    } catch (_: Exception) {
                        false
                    }
                }
                if (ok || !target.exists()) {
                    deletedCount++
                    freedBytes += item.sizeBytes
                }
            }
        }
        Pair(deletedCount, freedBytes)
    }

    fun deleteDirectoryRecursively(dir: File): Boolean {
        val children = try { dir.listFiles() } catch (_: Exception) { null }
        if (children != null) {
            for (child in children) {
                if (child.isDirectory) {
                    deleteDirectoryRecursively(child)
                } else {
                    try { child.delete() } catch (_: Exception) {}
                }
            }
        }
        return try { dir.delete() } catch (_: Exception) { false }
    }
}
