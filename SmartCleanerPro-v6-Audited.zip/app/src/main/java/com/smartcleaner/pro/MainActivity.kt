package com.smartcleaner.pro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class AppNavTab(val titleAr: String) {
    SMART_CLEANER("التنظيف الذكي"),
    AI_COMPRESSOR("ضغط الوسائط AI"),
    APPS_AND_RAM("التطبيقات والرام"),
    VAULT_AND_SAFETY("الخزنة والحماية")
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                SmartCleanerTheme {
                    CleanerAppScreen(
                        checkStoragePermission = { hasStoragePermission() },
                        requestManageAllFiles = { openManageAllFilesSettings() },
                        getAppCacheDirs = {
                            val list = mutableListOf<File>()
                            cacheDir?.let { list.add(it) }
                            externalCacheDir?.let { list.add(it) }
                            list
                        }
                    )
                }
            }
        }
    }

    private fun hasStoragePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            val read = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            val write = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            read && write
        }
    }

    private fun openManageAllFilesSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                startActivity(intent)
            }
        }
    }
}

@Composable
fun SmartCleanerTheme(content: @Composable () -> Unit) {
    val darkColorScheme = darkColorScheme(
        primary = Color(0xFF00E676),
        secondary = Color(0xFF00B0FF),
        tertiary = Color(0xFFE040FB),
        background = Color(0xFF0A1118),
        surface = Color(0xFF131F2C),
        onPrimary = Color.Black,
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(
        colorScheme = darkColorScheme,
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CleanerAppScreen(
    checkStoragePermission: () -> Boolean,
    requestManageAllFiles: () -> Unit,
    getAppCacheDirs: () -> List<File>
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var currentTab by remember { mutableStateOf(AppNavTab.SMART_CLEANER) }
    var hasPermission by remember { mutableStateOf(checkStoragePermission()) }
    var storageStats by remember { mutableStateOf(CleanerEngine.getStorageStats()) }
    var ramStatus by remember { mutableStateOf(AppAndSystemManager.getRamStatus(context)) }
    var scannedItems by remember { mutableStateOf<List<ScannedItem>>(emptyList()) }
    var installedApps by remember { mutableStateOf<List<InstalledAppItem>>(emptyList()) }
    var isLoadingApps by remember { mutableStateOf(false) }

    var whitelistedPaths by remember { mutableStateOf(SafetyAndVaultManager.getWhitelistedPaths(context)) }
    var quarantineEntries by remember { mutableStateOf(SafetyAndVaultManager.getQuarantineEntries(context)) }
    var useQuarantineVault by remember { mutableStateOf(SafetyAndVaultManager.isQuarantineEnabled(context)) }
    var autoCleanScheduled by remember { mutableStateOf(SafetyAndVaultManager.isAutoCleanEnabled(context)) }

    var isScanning by remember { mutableStateOf(false) }
    var isCleaning by remember { mutableStateOf(false) }
    var isCompressing by remember { mutableStateOf(false) }
    var compressionMode by remember { mutableStateOf(AiCompressionMode.BALANCED_AI) }
    var progressMessage by remember { mutableStateOf("محرك الذكاء الاصطناعي الشامل (Offline AI v6.0 Audited) جاهز") }
    var lastCleanSummary by remember { mutableStateOf<String?>(null) }
    var selectedCategoryFilter by remember { mutableStateOf<CleanCategory?>(null) }
    var previewDialogItem by remember { mutableStateOf<ScannedItem?>(null) }

    val aiInsight = remember(storageStats, scannedItems) {
        AiOfflineBrain.generateStorageInsight(storageStats, scannedItems)
    }

    val compressibleItems = remember(scannedItems) {
        scannedItems.filter { it.category == CleanCategory.COMPRESSIBLE_MEDIA_AI }
    }

    val legacyPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        hasPermission = checkStoragePermission()
        storageStats = CleanerEngine.getStorageStats()
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        autoCleanScheduled = true
        AutoCleanJobService.schedulePeriodicAutoClean(context, true)
    }

    // Automatically refresh permission & stats when user returns from Android Settings (ON_RESUME)
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasPermission = checkStoragePermission()
                storageStats = CleanerEngine.getStorageStats()
                ramStatus = AppAndSystemManager.getRamStatus(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(currentTab) {
        if (currentTab == AppNavTab.APPS_AND_RAM && installedApps.isEmpty()) {
            isLoadingApps = true
            installedApps = AppAndSystemManager.scanInstalledUserApps(context)
            ramStatus = AppAndSystemManager.getRamStatus(context)
            isLoadingApps = false
        } else if (currentTab == AppNavTab.VAULT_AND_SAFETY) {
            whitelistedPaths = SafetyAndVaultManager.getWhitelistedPaths(context)
            quarantineEntries = SafetyAndVaultManager.getQuarantineEntries(context)
        }
    }

    val totalSelectedBytes = remember(scannedItems) {
        scannedItems.filter { it.isSelected }.sumOf { it.sizeBytes }
    }
    val totalSelectedCount = remember(scannedItems) {
        scannedItems.count { it.isSelected }
    }

    previewDialogItem?.let { targetItem ->
        MediaPreviewComparisonDialog(
            item = targetItem,
            mode = compressionMode,
            onDismiss = { previewDialogItem = null },
            onCompressNow = {
                previewDialogItem = null
                scope.launch {
                    isCompressing = true
                    val res = AiMediaCompressor.compressItemsInPlace(
                        context = context,
                        items = listOf(targetItem),
                        mode = compressionMode,
                        onProgress = { msg -> progressMessage = msg }
                    )
                    storageStats = CleanerEngine.getStorageStats()
                    lastCleanSummary = res.detailsAr
                    scannedItems = scannedItems.mapNotNull { existing ->
                        if (existing.path == targetItem.path) {
                            if (res.compressedCount > 0) null else existing
                        } else existing
                    }
                    isCompressing = false
                }
            },
            onWhitelistFile = {
                SafetyAndVaultManager.addToWhitelist(context, targetItem.path)
                whitelistedPaths = SafetyAndVaultManager.getWhitelistedPaths(context)
                scannedItems = scannedItems.filterNot { it.path == targetItem.path }
                previewDialogItem = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "المنظف الذكي AI Ultimate",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF1E3A2F))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "v6.0 Audited",
                                        color = Color(0xFF00E676),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                            Text(
                                text = "dHash • ضغط الوسائط • مدير التطبيقات • الخزنة • جدولة ذكية",
                                fontSize = 10.sp,
                                color = Color(0xFF90A4AE)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        hasPermission = checkStoragePermission()
                        storageStats = CleanerEngine.getStorageStats()
                        ramStatus = AppAndSystemManager.getRamStatus(context)
                    }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "تحديث",
                            tint = Color(0xFF00B0FF)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D1824)
                )
            )
        },
        bottomBar = {
            Column {
                if (currentTab == AppNavTab.SMART_CLEANER && scannedItems.isNotEmpty() && !isScanning && !isCleaning && !isCompressing) {
                    Surface(
                        color = Color(0xFF101D2C),
                        tonalElevation = 8.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = if (useQuarantineVault) "نقل للخزنة المؤقتة: $totalSelectedCount عنصر" else "حذف نهائي: $totalSelectedCount عنصر",
                                    color = Color(0xFFB0BEC5),
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = CleanerEngine.formatSize(totalSelectedBytes),
                                    color = Color(0xFF00E676),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp
                                )
                            }

                            Button(
                                onClick = {
                                    scope.launch {
                                        isCleaning = true
                                        val (deletedCount, freedBytes) = CleanerEngine.deleteSelectedItems(
                                            context = context,
                                            items = scannedItems,
                                            useQuarantine = useQuarantineVault,
                                            onProgress = { msg -> progressMessage = msg }
                                        )
                                        storageStats = CleanerEngine.getStorageStats()
                                        quarantineEntries = SafetyAndVaultManager.getQuarantineEntries(context)
                                        lastCleanSummary = if (useQuarantineVault) {
                                            "تم تنظيف $deletedCount عنصر (${CleanerEngine.formatSize(freedBytes)}) مع حفظ نسخة استعادة في الخزنة!"
                                        } else {
                                            "تم حذف $deletedCount عنصر نهائياً وتوفير ${CleanerEngine.formatSize(freedBytes)}!"
                                        }
                                        scannedItems = scannedItems.filter { it.file.exists() }
                                        isCleaning = false
                                        progressMessage = "اكتمل التنظيف الذكي بنجاح"
                                    }
                                },
                                enabled = totalSelectedCount > 0,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFF5252),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.DeleteForever, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (useQuarantineVault) "تنظيف آمن (للخزنة)" else "حذف نهائي الآن",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }

                NavigationBar(containerColor = Color(0xFF0D1824)) {
                    NavigationBarItem(
                        selected = currentTab == AppNavTab.SMART_CLEANER,
                        onClick = { currentTab = AppNavTab.SMART_CLEANER },
                        icon = { Icon(Icons.Default.CleaningServices, contentDescription = null) },
                        label = { Text("الفحص الشامل", fontSize = 11.sp) }
                    )
                    NavigationBarItem(
                        selected = currentTab == AppNavTab.AI_COMPRESSOR,
                        onClick = { currentTab = AppNavTab.AI_COMPRESSOR },
                        icon = { Icon(Icons.Default.Compress, contentDescription = null) },
                        label = { Text("ضغط الوسائط", fontSize = 11.sp) }
                    )
                    NavigationBarItem(
                        selected = currentTab == AppNavTab.APPS_AND_RAM,
                        onClick = { currentTab = AppNavTab.APPS_AND_RAM },
                        icon = { Icon(Icons.Default.Memory, contentDescription = null) },
                        label = { Text("التطبيقات والرام", fontSize = 11.sp) }
                    )
                    NavigationBarItem(
                        selected = currentTab == AppNavTab.VAULT_AND_SAFETY,
                        onClick = { currentTab = AppNavTab.VAULT_AND_SAFETY },
                        icon = { Icon(Icons.Default.Shield, contentDescription = null) },
                        label = { Text("الخزنة والجدولة", fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { paddingValues ->
        when (currentTab) {
            AppNavTab.SMART_CLEANER -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0A1118))
                        .padding(paddingValues)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    item {
                        StorageHeaderCard(storageStats = storageStats)
                    }

                    item {
                        AiAdvisorCard(
                            insight = aiInsight,
                            hasScannedItems = scannedItems.isNotEmpty(),
                            onSmartAiSelect = {
                                scannedItems = scannedItems.map { item ->
                                    item.copy(
                                        isSelected = item.aiSafetyScore >= 85 &&
                                            item.category != CleanCategory.LARGE_FILES &&
                                            item.category != CleanCategory.COMPRESSIBLE_MEDIA_AI
                                    )
                                }
                            }
                        )
                    }

                    if (!hasPermission) {
                        item {
                            PermissionBannerCard(
                                onGrantClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                        requestManageAllFiles()
                                    } else {
                                        legacyPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                                            )
                                        )
                                    }
                                },
                                onCheckAgain = {
                                    hasPermission = checkStoragePermission()
                                    storageStats = CleanerEngine.getStorageStats()
                                }
                            )
                        }
                    }

                    item {
                        ScanControlCard(
                            isScanning = isScanning,
                            isCleaning = isCleaning || isCompressing,
                            progressMessage = progressMessage,
                            lastCleanSummary = lastCleanSummary,
                            onStartScan = {
                                hasPermission = checkStoragePermission()
                                scope.launch {
                                    isScanning = true
                                    lastCleanSummary = null
                                    selectedCategoryFilter = null
                                    whitelistedPaths = SafetyAndVaultManager.getWhitelistedPaths(context)
                                    scannedItems = CleanerEngine.performFullScan(
                                        appCacheDirs = getAppCacheDirs(),
                                        whitelist = whitelistedPaths,
                                        onProgress = { msg -> progressMessage = msg }
                                    )
                                    storageStats = CleanerEngine.getStorageStats()
                                    isScanning = false
                                    progressMessage = if (scannedItems.isEmpty()) {
                                        "الذاكرة نقية تماماً! لم يرصد الذكاء الاصطناعي أي مخلفات."
                                    } else {
                                        "اكتمل التحليل العصبي المحلي: تم رصد ${scannedItems.size} عنصر"
                                    }
                                }
                            }
                        )
                    }

                    if (scannedItems.isNotEmpty()) {
                        item {
                            Text(
                                text = "تصنيفات الذكاء الاصطناعي (اضغط لتصفية الملفات):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                        }

                        items(CleanCategory.values().toList()) { category ->
                            val catItems = scannedItems.filter { it.category == category }
                            val catBytes = catItems.sumOf { it.sizeBytes }
                            val allChecked = catItems.isNotEmpty() && catItems.all { it.isSelected }

                            CategorySummaryCard(
                                category = category,
                                itemCount = catItems.size,
                                totalBytes = catBytes,
                                isAllChecked = allChecked,
                                isSelectedFilter = selectedCategoryFilter == category,
                                onToggleCategorySelection = { checked ->
                                    scannedItems = scannedItems.map { item ->
                                        if (item.category == category) item.copy(isSelected = checked) else item
                                    }
                                },
                                onCardClick = {
                                    selectedCategoryFilter =
                                        if (selectedCategoryFilter == category) null else category
                                }
                            )
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val headerTitle = selectedCategoryFilter?.titleAr ?: "جميع الملفات المكتشفة (اضغط للمعاينة)"
                                Text(
                                    text = headerTitle,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color(0xFF00E676)
                                )
                                if (selectedCategoryFilter != null) {
                                    TextButton(onClick = { selectedCategoryFilter = null }) {
                                        Text("عرض الكل", color = Color(0xFF00B0FF))
                                    }
                                }
                            }
                        }

                        val filteredItems = if (selectedCategoryFilter != null) {
                            scannedItems.filter { it.category == selectedCategoryFilter }
                        } else {
                            scannedItems
                        }

                        items(filteredItems, key = { it.path }) { item ->
                            ScannedFileRow(
                                item = item,
                                isCompressing = isCompressing,
                                onCheckedChange = { checked ->
                                    scannedItems = scannedItems.map {
                                        if (it.path == item.path) it.copy(isSelected = checked) else it
                                    }
                                },
                                onPreviewClick = { previewDialogItem = item },
                                onWhitelistFolderClick = {
                                    val folderPath = item.file.parentFile?.absolutePath ?: item.path
                                    SafetyAndVaultManager.addToWhitelist(context, folderPath)
                                    whitelistedPaths = SafetyAndVaultManager.getWhitelistedPaths(context)
                                    scannedItems = scannedItems.filterNot {
                                        SafetyAndVaultManager.isPathWhitelisted(it.path, whitelistedPaths)
                                    }
                                    lastCleanSummary = "تمت إضافة المجلد ($folderPath) إلى قائمة الاستثناءات الآمنة!"
                                },
                                onCompressSingleClick = {
                                    previewDialogItem = item
                                }
                            )
                        }
                    }
                }
            }

            AppNavTab.AI_COMPRESSOR -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0A1118))
                        .padding(paddingValues)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    item {
                        AiCompressionCenterCard(
                            compressibleItems = compressibleItems,
                            selectedMode = compressionMode,
                            isCompressing = isCompressing,
                            onSelectMode = { compressionMode = it },
                            onCompressAllClick = {
                                scope.launch {
                                    isCompressing = true
                                    val result = AiMediaCompressor.compressItemsInPlace(
                                        context = context,
                                        items = compressibleItems,
                                        mode = compressionMode,
                                        onProgress = { msg -> progressMessage = msg }
                                    )
                                    storageStats = CleanerEngine.getStorageStats()
                                    lastCleanSummary = result.detailsAr
                                    scannedItems = scannedItems.mapNotNull { existing ->
                                        if (!existing.file.exists()) return@mapNotNull null
                                        if (existing.category == CleanCategory.COMPRESSIBLE_MEDIA_AI) {
                                            val recheck = AiMediaCompressor.analyzeMediaCompressibility(existing.file)
                                            if (recheck.isCompressible && recheck.estimatedSavedBytes > 250L * 1024L) {
                                                existing.copy(
                                                    sizeBytes = existing.file.length(),
                                                    aiReasonAr = recheck.explanationAr,
                                                    estimatedCompressionSavingsBytes = recheck.estimatedSavedBytes
                                                )
                                            } else null
                                        } else existing.copy(sizeBytes = existing.file.length())
                                    }
                                    isCompressing = false
                                }
                            }
                        )
                    }

                    if (compressibleItems.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF131F2C))
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        Icons.Default.PhotoLibrary,
                                        contentDescription = null,
                                        tint = Color(0xFF00E676),
                                        modifier = Modifier.size(42.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "اضغط على 'بدء الفحص الذكي' في تبويب الفحص الشامل لاكتشاف الصور والفيديوهات القابلة للضغط، ثم اضغط على أي صورة لمعاينة جودتها قبل وبعد الضغط.",
                                        color = Color(0xFFB0BEC5),
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    } else {
                        item {
                            Text(
                                text = "اضغط على أي صورة أو فيديو لمعاينة الجودة (قبل / بعد الضغط):",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        items(compressibleItems, key = { it.path }) { item ->
                            ScannedFileRow(
                                item = item,
                                isCompressing = isCompressing,
                                onCheckedChange = {},
                                onPreviewClick = { previewDialogItem = item },
                                onWhitelistFolderClick = {
                                    SafetyAndVaultManager.addToWhitelist(context, item.path)
                                    whitelistedPaths = SafetyAndVaultManager.getWhitelistedPaths(context)
                                    scannedItems = scannedItems.filterNot { it.path == item.path }
                                },
                                onCompressSingleClick = { previewDialogItem = item }
                            )
                        }
                    }
                }
            }

            AppNavTab.APPS_AND_RAM -> {
                val hasUsagePerm = AppAndSystemManager.hasUsageStatsPermission(context)
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0A1118))
                        .padding(paddingValues)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    item {
                        RamOptimizerCard(
                            ramStatus = ramStatus,
                            onBoostClick = {
                                scope.launch {
                                    val (killed, freedBytes) = AppAndSystemManager.boostRamAndKillBackground(context)
                                    ramStatus = AppAndSystemManager.getRamStatus(context)
                                    lastCleanSummary = "تم إغلاق $killed عملية خلفية وتحرير ${CleanerEngine.formatSize(freedBytes)} من الرام!"
                                }
                            }
                        )
                    }

                    if (!hasUsagePerm) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF231D33))
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "تفعيل كاشف التطبيقات المهجورة وحجم الكاش العميق",
                                        color = Color(0xFFE040FB),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "امنح صلاحية إحصائيات الاستخدام (Usage Access) لمعرفة التطبيقات التي لم تفتحها منذ شهور وحجم الكاش المخفي لكل تطبيق.",
                                        color = Color(0xFFCFD8DC),
                                        fontSize = 12.sp
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = { AppAndSystemManager.openUsageAccessSettings(context) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE040FB))
                                    ) {
                                        Text("تفعيل صلاحية Usage Access", color = Color.White)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "مدير التطبيقات والنسخ الاحتياطي APK (${installedApps.size}):",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            TextButton(onClick = {
                                scope.launch {
                                    isLoadingApps = true
                                    installedApps = AppAndSystemManager.scanInstalledUserApps(context)
                                    isLoadingApps = false
                                }
                            }) {
                                Text("تحديث القائمة", color = Color(0xFF00E676))
                            }
                        }
                    }

                    if (isLoadingApps) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Color(0xFF00E676))
                            }
                        }
                    } else {
                        items(installedApps, key = { it.packageName }) { app ->
                            InstalledAppRow(
                                app = app,
                                onBackupApk = {
                                    scope.launch {
                                        val savedPath = AppAndSystemManager.backupAppApk(app)
                                        lastCleanSummary = if (savedPath != null) {
                                            "تم حفظ نسخة APK الاحتياطية في: $savedPath"
                                        } else {
                                            "تعذر نسخ ملف الـ APK"
                                        }
                                    }
                                },
                                onOpenCacheSettings = {
                                    AppAndSystemManager.openAppSystemSettings(context, app.packageName)
                                },
                                onUninstall = {
                                    AppAndSystemManager.requestUninstallApp(context, app.packageName)
                                }
                            )
                        }
                    }
                }
            }

            AppNavTab.VAULT_AND_SAFETY -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0A1118))
                        .padding(paddingValues)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(vertical = 14.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF131F2C))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "الأتمتة الذكية وإعدادات الحماية",
                                    color = Color(0xFF00E676),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "تفعيل خزنة الاستعادة المؤقتة (Quarantine Vault)",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "نقل الملفات المحذوفة إلى الخزنة أولاً لتتمكن من استعادتها إذا حذفت شيئاً بالخطأ",
                                            color = Color(0xFF90A4AE),
                                            fontSize = 11.sp
                                        )
                                    }
                                    Switch(
                                        checked = useQuarantineVault,
                                        onCheckedChange = {
                                            useQuarantineVault = it
                                            SafetyAndVaultManager.setQuarantineEnabled(context, it)
                                        }
                                    )
                                }

                                Divider(modifier = Modifier.padding(vertical = 10.dp), color = Color(0xFF263238))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "المنظف التلقائي المجدول في الخلفية (كل 24 ساعة)",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = "ينظف سلة المهملات والملفات المؤقتة تلقائياً في الخلفية ويرسل إشعاراً بالمساحة الموفرة",
                                            color = Color(0xFF90A4AE),
                                            fontSize = 11.sp
                                        )
                                    }
                                    Switch(
                                        checked = autoCleanScheduled,
                                        onCheckedChange = { enable ->
                                            if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                val notifGranted = ContextCompat.checkSelfPermission(
                                                    context,
                                                    Manifest.permission.POST_NOTIFICATIONS
                                                ) == PackageManager.PERMISSION_GRANTED
                                                if (!notifGranted) {
                                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                    return@Switch
                                                }
                                            }
                                            autoCleanScheduled = enable
                                            AutoCleanJobService.schedulePeriodicAutoClean(context, enable)
                                        }
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "خزنة الاستعادة المؤقتة (${quarantineEntries.size} ملف):",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            if (quarantineEntries.isNotEmpty()) {
                                TextButton(onClick = {
                                    scope.launch {
                                        val purged = SafetyAndVaultManager.purgeAllQuarantine(context)
                                        quarantineEntries = emptyList()
                                        storageStats = CleanerEngine.getStorageStats()
                                        lastCleanSummary = "تم إفراغ الخزنة نهائياً وتوفير ${CleanerEngine.formatSize(purged)}"
                                    }
                                }) {
                                    Text("إفراغ الخزنة نهائياً", color = Color(0xFFFF5252))
                                }
                            }
                        }
                    }

                    if (quarantineEntries.isEmpty()) {
                        item {
                            Text(
                                text = "الخزنة فارغة حالياً.",
                                color = Color(0xFF78909C),
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        items(quarantineEntries, key = { it.id }) { entry ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF101A26))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = entry.originalName,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = entry.originalPath,
                                            color = Color(0xFF78909C),
                                            fontSize = 10.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = CleanerEngine.formatSize(entry.sizeBytes),
                                            color = Color(0xFFFFAB40),
                                            fontSize = 11.sp
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                SafetyAndVaultManager.restoreFromQuarantine(context, entry)
                                                quarantineEntries = SafetyAndVaultManager.getQuarantineEntries(context)
                                                storageStats = CleanerEngine.getStorageStats()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676))
                                    ) {
                                        Text("استعادة", color = Color.Black, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text(
                            text = "قائمة الاستثناءات والمجلدات المحمية (${whitelistedPaths.size}):",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    if (whitelistedPaths.isEmpty()) {
                        item {
                            Text(
                                text = "لا توجد مسارات مستثناة. يمكنك الضغط على أيقونة الدرع بجوار أي ملف أثناء الفحص لحماية مجلده.",
                                color = Color(0xFF78909C),
                                fontSize = 12.sp
                            )
                        }
                    } else {
                        items(whitelistedPaths.toList(), key = { it }) { path ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF101A26))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = path,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = {
                                        SafetyAndVaultManager.removeFromWhitelist(context, path)
                                        whitelistedPaths = SafetyAndVaultManager.getWhitelistedPaths(context)
                                    }) {
                                        Icon(Icons.Default.Close, contentDescription = "إزالة", tint = Color(0xFFFF5252))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MediaPreviewComparisonDialog(
    item: ScannedItem,
    mode: AiCompressionMode,
    onDismiss: () -> Unit,
    onCompressNow: () -> Unit,
    onWhitelistFile: () -> Unit
) {
    var previewData by remember { mutableStateOf<ImagePreviewComparison?>(null) }
    var showAfterCompressed by remember { mutableStateOf(true) }

    LaunchedEffect(item.path, mode) {
        if (AiMediaCompressor.isSupportedMedia(item.file)) {
            previewData = AiMediaCompressor.generateBeforeAfterPreview(item.file, mode)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, Color(0xFF00E676), RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1B28))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "معاينة ذكية ومقارنة الجودة (قبل / بعد)",
                    color = Color(0xFF00E676),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = item.name,
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(10.dp))

                val bmpToDisplay = if (showAfterCompressed) {
                    previewData?.compressedPreviewBitmap ?: previewData?.originalBitmap
                } else {
                    previewData?.originalBitmap
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF070D14)),
                    contentAlignment = Alignment.Center
                ) {
                    if (bmpToDisplay != null) {
                        Image(
                            bitmap = bmpToDisplay.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.InsertDriveFile,
                            contentDescription = null,
                            tint = Color(0xFF00B0FF),
                            modifier = Modifier.size(64.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xCC000000))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (showAfterCompressed) "بعد الضغط الذكي (AI)" else "الأصل (قبل الضغط)",
                            color = if (showAfterCompressed) Color(0xFF00E676) else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (previewData != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        FilterChip(
                            selected = !showAfterCompressed,
                            onClick = { showAfterCompressed = false },
                            label = {
                                Text("قبل: ${CleanerEngine.formatSize(previewData!!.originalSizeBytes)}")
                            }
                        )
                        FilterChip(
                            selected = showAfterCompressed,
                            onClick = { showAfterCompressed = true },
                            label = {
                                Text("بعد: ~${CleanerEngine.formatSize(previewData!!.simulatedCompressedBytes)}")
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = item.aiReasonAr,
                    color = Color(0xFF80D8FF),
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (AiMediaCompressor.isSupportedMedia(item.file)) {
                        Button(
                            onClick = onCompressNow,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676))
                        ) {
                            Text("ضغط وحفظ الآن", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                    OutlinedButton(
                        onClick = onWhitelistFile,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("استثناء وحماية", color = Color(0xFFFFAB40), fontSize = 12.sp)
                    }
                }

                TextButton(onClick = onDismiss) {
                    Text("إغلاق", color = Color(0xFFB0BEC5))
                }
            }
        }
    }
}

@Composable
fun RamOptimizerCard(
    ramStatus: RamStatus,
    onBoostClick: () -> Unit
) {
    val ramPercent = (ramStatus.usageRatio * 100).toInt()
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131F2C))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "مسرع الرام والعمليات الخلفية (RAM Booster)",
                        color = Color(0xFF00B0FF),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "المستخدم: ${CleanerEngine.formatSize(ramStatus.usedRamBytes)} من ${CleanerEngine.formatSize(ramStatus.totalRamBytes)}",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "الرام المتاح: ${CleanerEngine.formatSize(ramStatus.availableRamBytes)}",
                        color = Color(0xFF00E676),
                        fontSize = 12.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .border(2.dp, Color(0xFF00B0FF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$ramPercent%",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onBoostClick,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B0FF))
            ) {
                Icon(Icons.Default.Speed, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تحرير الرام وإغلاق تطبيقات الخلفية الآن", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun InstalledAppRow(
    app: InstalledAppItem,
    onBackupApk: () -> Unit,
    onOpenCacheSettings: () -> Unit,
    onUninstall: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101A26))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = app.appName,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = app.packageName,
                        color = Color(0xFF78909C),
                        fontSize = 11.sp
                    )
                    val unusedText = if (app.daysUnused > 30) {
                        "مهجور منذ ${app.daysUnused} يوم"
                    } else {
                        "آخر استخدام منذ ${app.daysUnused} يوم"
                    }
                    Text(
                        text = "$unusedText • حجم الكاش: ${CleanerEngine.formatSize(app.cacheBytes)}",
                        color = if (app.daysUnused > 30) Color(0xFFFFAB40) else Color(0xFF80D8FF),
                        fontSize = 11.sp
                    )
                }
                Text(
                    text = CleanerEngine.formatSize(app.apkSizeBytes + app.cacheBytes),
                    color = Color(0xFF00E676),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onBackupApk,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    Text("نسخ APK", fontSize = 11.sp, color = Color(0xFF00E676))
                }
                OutlinedButton(
                    onClick = onOpenCacheSettings,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    Text("مسح الكاش", fontSize = 11.sp, color = Color(0xFF00B0FF))
                }
                OutlinedButton(
                    onClick = onUninstall,
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    Text("إلغاء تثبيت", fontSize = 11.sp, color = Color(0xFFFF5252))
                }
            }
        }
    }
}

@Composable
fun AiCompressionCenterCard(
    compressibleItems: List<ScannedItem>,
    selectedMode: AiCompressionMode,
    isCompressing: Boolean,
    onSelectMode: (AiCompressionMode) -> Unit,
    onCompressAllClick: () -> Unit
) {
    val totalOriginalBytes = remember(compressibleItems) {
        compressibleItems.sumOf { it.sizeBytes }
    }
    val totalExpectedSavings = remember(compressibleItems, selectedMode) {
        val baseSavings = compressibleItems.sumOf { it.estimatedCompressionSavingsBytes }
        when (selectedMode) {
            AiCompressionMode.BALANCED_AI -> baseSavings
            AiCompressionMode.MAX_SAVER_AI -> (baseSavings * 1.22).toLong().coerceAtMost((totalOriginalBytes * 0.80).toLong())
            AiCompressionMode.ULTRA_QUALITY_AI -> (baseSavings * 0.75).toLong()
        }
    }
    val imageCount = remember(compressibleItems) {
        compressibleItems.count { !AiMediaCompressor.isVideoFile(it.file) }
    }
    val videoCount = remember(compressibleItems) {
        compressibleItems.count { AiMediaCompressor.isVideoFile(it.file) }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, Color(0xFF00E676), RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F241D))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF122C24), Color(0xFF0D1B26))
                    )
                )
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.PhotoSizeSelectSmall,
                    contentDescription = null,
                    tint = Color(0xFF00E676),
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "ضغط الصور والفيديوهات بالـ AI (بدون حذف)",
                        color = Color(0xFF00E676),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "$imageCount صورة و $videoCount فيديو قابلة للتصغير مع معاينة قبل/بعد",
                        color = Color(0xFFB0BEC5),
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF09141C))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("الحجم الحالي", color = Color(0xFF90A4AE), fontSize = 11.sp)
                    Text(
                        text = CleanerEngine.formatSize(totalOriginalBytes),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = null,
                    tint = Color(0xFF00E676)
                )
                Column(horizontalAlignment = Alignment.End) {
                    Text("المساحة المتوقع توفيرها بالضغط", color = Color(0xFF00E676), fontSize = 11.sp)
                    Text(
                        text = "توفير ~${CleanerEngine.formatSize(totalExpectedSavings)}",
                        color = Color(0xFF00E676),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            AiCompressionMode.values().forEach { mode ->
                val selected = mode == selectedMode
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) Color(0xFF1B3B2B) else Color(0xFF101D28))
                        .clickable { onSelectMode(mode) }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selected,
                        onClick = { onSelectMode(mode) },
                        colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF00E676))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = mode.titleAr,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = mode.subtitleAr,
                            color = Color(0xFFB0BEC5),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onCompressAllClick,
                enabled = !isCompressing && compressibleItems.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00E676),
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Compress, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isCompressing) "جاري ضغط الوسائط بالـ AI..." else "ضغط جميع الصور والفيديوهات الآن بدون حذفها",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
fun AiAdvisorCard(
    insight: AiStorageInsight,
    hasScannedItems: Boolean,
    onSmartAiSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF7C4DFF), RoundedCornerShape(18.dp)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF171429))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF1F1938), Color(0xFF121828))
                    )
                )
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = Color(0xFFE040FB),
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "المستشار الذكي المحلي (بدون إنترنت)",
                        color = Color(0xFFE040FB),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF2B224B))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "صحة الذاكرة ${insight.healthScore}%",
                        color = Color(0xFF00E676),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = insight.headlineAr,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = insight.detailsAr,
                color = Color(0xFFB0BEC5),
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "🔮 توقع الـ AI: ${insight.recommendedActionAr}",
                color = Color(0xFF80D8FF),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )

            if (hasScannedItems) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onSmartAiSelect,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE040FB))
                ) {
                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تحديد ذكي تلقائي للمخلفات الآمنة للحذف (ثقة +85%)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun AnimatedAiRadarBadge(isActive: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier.size(76.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = size.minDimension / 2f
            drawCircle(
                color = Color(0x2200E676),
                radius = radius * (if (isActive) pulseScale else 0.9f)
            )
            drawCircle(
                color = Color(0xFF00E5FF),
                radius = radius * 0.85f,
                style = Stroke(width = 2.dp.toPx())
            )
            if (isActive) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(Color.Transparent, Color(0xAA00E676), Color(0xFF00E5FF))
                    ),
                    startAngle = sweepAngle,
                    sweepAngle = 110f,
                    useCenter = true
                )
            }
        }
        Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = Color(0xFFFFD740),
            modifier = Modifier.size(30.dp)
        )
    }
}

@Composable
fun StorageHeaderCard(storageStats: StorageStats) {
    val usedPercent = (storageStats.usedRatio * 100).toInt()
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131F2C))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF162638), Color(0xFF0F1A26))
                    )
                )
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "مساحة التخزين الداخلية",
                        color = Color(0xFFB0BEC5),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "المستخدم: ${CleanerEngine.formatSize(storageStats.usedBytes)} من ${CleanerEngine.formatSize(storageStats.totalBytes)}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "المتاح حالياً: ${CleanerEngine.formatSize(storageStats.freeBytes)}",
                        color = Color(0xFF00E676),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .size(66.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0A1118))
                        .border(3.dp, if (usedPercent > 85) Color(0xFFFF5252) else Color(0xFF00E676), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$usedPercent%",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            LinearProgressIndicator(
                progress = { storageStats.usedRatio },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = if (usedPercent > 85) Color(0xFFFF5252) else Color(0xFF00E676),
                trackColor = Color(0xFF263238)
            )
        }
    }
}

@Composable
fun PermissionBannerCard(
    onGrantClick: () -> Unit,
    onCheckAgain: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1B1E))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = Color(0xFFFFAB40)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "مطلوب إذن الوصول الشامل للملفات",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFAB40),
                    fontSize = 16.sp
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "حتى يتمكن محرك الذكاء الاصطناعي من فحص البصمة البصرية dHash وضغط الصور والفيديوهات وحذف سلة المهملات (.Trash)، امنحه صلاحية إدارة كل الملفات.",
                color = Color(0xFFECEFF1),
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onGrantClick,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFAB40)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("منح الصلاحية الآن", color = Color.Black, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onCheckAgain,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("تحققت من الصلاحية", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun ScanControlCard(
    isScanning: Boolean,
    isCleaning: Boolean,
    progressMessage: String,
    lastCleanSummary: String?,
    onStartScan: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131F2C))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedAiRadarBadge(isActive = isScanning || isCleaning)
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = progressMessage,
                color = Color(0xFFE0E0E0),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            AnimatedVisibility(visible = lastCleanSummary != null) {
                lastCleanSummary?.let { summary ->
                    Box(
                        modifier = Modifier
                            .padding(top = 10.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0E3322))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF00E676)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = summary,
                                color = Color(0xFF00E676),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onStartScan,
                enabled = !isScanning && !isCleaning,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00E676),
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isScanning) "جاري التحليل العصبي الشامل (Offline AI)..." else "بدء الفحص الذكي الشامل بالـ AI",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun CategorySummaryCard(
    category: CleanCategory,
    itemCount: Int,
    totalBytes: Long,
    isAllChecked: Boolean,
    isSelectedFilter: Boolean,
    onToggleCategorySelection: (Boolean) -> Unit,
    onCardClick: () -> Unit
) {
    val badgeColor = Color(category.badgeColorHex)
    val isCompressCategory = category == CleanCategory.COMPRESSIBLE_MEDIA_AI
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .then(
                if (isSelectedFilter) Modifier.border(2.dp, badgeColor, RoundedCornerShape(16.dp))
                else Modifier
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF152230))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isCompressCategory) {
                Icon(
                    imageVector = Icons.Default.Compress,
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier
                        .padding(horizontal = 10.dp)
                        .size(26.dp)
                )
            } else {
                Checkbox(
                    checked = isAllChecked,
                    onCheckedChange = { onToggleCategorySelection(it) },
                    enabled = itemCount > 0,
                    colors = CheckboxDefaults.colors(checkedColor = badgeColor)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(badgeColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = category.titleAr,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = category.subtitleAr,
                    fontSize = 12.sp,
                    color = Color(0xFF90A4AE)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CleanerEngine.formatSize(totalBytes),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = if (totalBytes > 0) badgeColor else Color(0xFF607D8B)
                )
                Text(
                    text = "$itemCount عنصر",
                    fontSize = 12.sp,
                    color = Color(0xFFB0BEC5)
                )
            }
        }
    }
}

@Composable
fun ScannedFileRow(
    item: ScannedItem,
    isCompressing: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    onPreviewClick: () -> Unit,
    onWhitelistFolderClick: () -> Unit,
    onCompressSingleClick: () -> Unit
) {
    val badgeColor = Color(item.category.badgeColorHex)
    val isCompressibleItem = item.category == CleanCategory.COMPRESSIBLE_MEDIA_AI ||
        AiMediaCompressor.isSupportedMedia(item.file)

    var thumbnailBitmap by remember(item.path) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(item.path) {
        if (!item.isDirectory && AiMediaCompressor.isSupportedMedia(item.file)) {
            withContext(Dispatchers.IO) {
                thumbnailBitmap = AiMediaCompressor.loadThumbnailBitmap(item.file, 84)
            }
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPreviewClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF101A26))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (item.category != CleanCategory.COMPRESSIBLE_MEDIA_AI) {
                Checkbox(
                    checked = item.isSelected,
                    onCheckedChange = onCheckedChange,
                    colors = CheckboxDefaults.colors(checkedColor = badgeColor)
                )
            }

            if (thumbnailBitmap != null) {
                Image(
                    bitmap = thumbnailBitmap!!.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.dp, badgeColor, RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = when {
                        item.isDirectory -> Icons.Default.FolderDelete
                        AiMediaCompressor.isVideoFile(item.file) -> Icons.Default.VideoFile
                        AiMediaCompressor.isSupportedMedia(item.file) -> Icons.Default.Image
                        else -> Icons.Default.InsertDriveFile
                    },
                    contentDescription = null,
                    tint = badgeColor,
                    modifier = Modifier.size(30.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (item.aiReasonAr.isNotEmpty()) {
                    Text(
                        text = item.aiReasonAr,
                        color = Color(0xFF80D8FF),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = item.path,
                    color = Color(0xFF78909C),
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onWhitelistFolderClick,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "استثناء المجلد",
                    tint = Color(0xFF90A4AE),
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = CleanerEngine.formatSize(item.sizeBytes),
                    color = badgeColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                if (isCompressibleItem && !item.isDirectory) {
                    Spacer(modifier = Modifier.height(4.dp))
                    FilledTonalButton(
                        onClick = onCompressSingleClick,
                        enabled = !isCompressing,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF1B3B2B),
                            contentColor = Color(0xFF00E676)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "معاينة وضغط",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Text(
                        text = "أمان ${item.aiSafetyScore}%",
                        color = if (item.aiSafetyScore >= 85) Color(0xFF00E676) else Color(0xFFFFAB40),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
