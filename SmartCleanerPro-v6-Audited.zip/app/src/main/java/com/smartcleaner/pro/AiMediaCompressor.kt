package com.smartcleaner.pro

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.media.ThumbnailUtils
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

enum class AiCompressionMode(
    val titleAr: String,
    val subtitleAr: String,
    val baseImageQuality: Int,
    val maxImageDimension: Int,
    val videoBitrateReductionFactor: Float,
    val targetFpsCap: Int
) {
    BALANCED_AI(
        "الوضع الذكي المتوازن (AI Balanced)",
        "يحافظ على جودة بصرية ممتازة للعين مع توفير 55% إلى 75% من الحجم",
        76,
        1920,
        0.48f,
        30
    ),
    MAX_SAVER_AI(
        "أقصى توفير للمساحة (AI Max Saver)",
        "ضغط عميق للصور والفيديوهات لتوفير حتى 80% من المساحة",
        64,
        1600,
        0.35f,
        25
    ),
    ULTRA_QUALITY_AI(
        "الجودة الفائقة (AI Lossless-Like)",
        "ضغط خفيف بدون أي فقدان ملحوظ في التفاصيل الدقيقة",
        86,
        2560,
        0.65f,
        30
    )
}

data class CompressionAnalysis(
    val isCompressible: Boolean,
    val isVideo: Boolean,
    val estimatedSavedBytes: Long,
    val explanationAr: String
)

data class BatchCompressionResult(
    val compressedCount: Int,
    val totalSavedBytes: Long,
    val detailsAr: String
)

data class ImagePreviewComparison(
    val originalBitmap: Bitmap?,
    val compressedPreviewBitmap: Bitmap?,
    val originalSizeBytes: Long,
    val simulatedCompressedBytes: Long,
    val dimensionsText: String
)

/**
 * محرك ضغط الصور والفيديوهات بالذكاء الاصطناعي المحلي (v6.0 - Audited)
 * الإصلاحات الجذرية المطبقة:
 * 1. استبدال ذري آمن للملفات (Atomic Safe File Swap with Rollback Backup) لمنع فقدان الصورة أو الفيديو الأصلي تحت أي ظرف.
 * 2. إغلاق مضمون لكائن MediaMetadataRetriever في كتلة finally لمنع تسريب الموارد الأصلية (Native Resource Leak).
 * 3. حساب الشفافية (hasTransparentPixels) مرة واحدة فقط لتجنب المسح المزدوج للبكسل.
 */
object AiMediaCompressor {

    private val imageExtensions = setOf("jpg", "jpeg", "png", "webp")
    private val videoExtensions = setOf("mp4", "mov", "3gp", "mkv", "webm")

    fun isSupportedMedia(file: File): Boolean {
        val ext = file.extension.lowercase(Locale.ROOT)
        return ext in imageExtensions || ext in videoExtensions
    }

    fun isImageFile(file: File): Boolean {
        return file.extension.lowercase(Locale.ROOT) in imageExtensions
    }

    fun isVideoFile(file: File): Boolean {
        return file.extension.lowercase(Locale.ROOT) in videoExtensions
    }

    /**
     * استبدال ذري آمن للملف الأصلي بالملف المضغوط مع التراجع التلقائي (Rollback) عند حدوث أي خطأ في نظام الملفات
     */
    private fun atomicReplaceFileSafely(originalFile: File, newTempFile: File, origModified: Long): Boolean {
        val parent = originalFile.parentFile ?: return false
        val backupFile = File(parent, ".ai_bak_${System.currentTimeMillis()}_${originalFile.name}")
        return try {
            val backedUp = originalFile.renameTo(backupFile) || run {
                originalFile.copyTo(backupFile, overwrite = true)
                originalFile.delete()
            }
            if (!backedUp || !backupFile.exists()) {
                if (backupFile.exists()) backupFile.delete()
                return false
            }

            val movedNew = newTempFile.renameTo(originalFile) || run {
                newTempFile.copyTo(originalFile, overwrite = true)
                newTempFile.delete()
            }

            if (movedNew && originalFile.exists() && originalFile.length() > 0L) {
                originalFile.setLastModified(origModified)
                backupFile.delete()
                true
            } else {
                // Rollback from backup immediately
                if (!originalFile.exists() || originalFile.length() == 0L) {
                    backupFile.renameTo(originalFile)
                }
                false
            }
        } catch (_: Throwable) {
            if ((!originalFile.exists() || originalFile.length() == 0L) && backupFile.exists()) {
                try { backupFile.renameTo(originalFile) } catch (_: Exception) {}
            }
            false
        }
    }

    fun loadThumbnailBitmap(file: File, reqSize: Int = 96): Bitmap? {
        if (!file.exists() || !file.isFile) return null
        return try {
            if (isImageFile(file)) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
                var sample = 1
                val maxDim = max(bounds.outWidth, bounds.outHeight)
                while (maxDim / sample > reqSize * 2) {
                    sample *= 2
                }
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeFile(file.absolutePath, opts)
            } else if (isVideoFile(file)) {
                @Suppress("DEPRECATION")
                ThumbnailUtils.createVideoThumbnail(
                    file.absolutePath,
                    MediaStore.Images.Thumbnails.MINI_KIND
                )
            } else null
        } catch (_: Throwable) {
            null
        }
    }

    suspend fun generateBeforeAfterPreview(
        file: File,
        mode: AiCompressionMode
    ): ImagePreviewComparison = withContext(Dispatchers.IO) {
        val origSize = file.length()
        if (!file.exists()) {
            return@withContext ImagePreviewComparison(null, null, origSize, origSize, "")
        }

        if (isVideoFile(file)) {
            val thumb = loadThumbnailBitmap(file, 360)
            val analysis = analyzeMediaCompressibility(file)
            val estAfter = (origSize - analysis.estimatedSavedBytes).coerceAtLeast(origSize / 3)
            return@withContext ImagePreviewComparison(
                originalBitmap = thumb,
                compressedPreviewBitmap = thumb,
                originalSizeBytes = origSize,
                simulatedCompressedBytes = estAfter,
                dimensionsText = "معاينة إطار الفيديو"
            )
        }

        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            val w = bounds.outWidth
            val h = bounds.outHeight
            if (w <= 0 || h <= 0) {
                return@withContext ImagePreviewComparison(null, null, origSize, origSize, "")
            }
            var sample = 1
            while (max(w, h) / sample > 1024) {
                sample *= 2
            }
            val origBmp = BitmapFactory.decodeFile(
                file.absolutePath,
                BitmapFactory.Options().apply { inSampleSize = sample }
            ) ?: return@withContext ImagePreviewComparison(null, null, origSize, origSize, "")

            val baos = ByteArrayOutputStream()
            origBmp.compress(Bitmap.CompressFormat.JPEG, mode.baseImageQuality, baos)
            val compressedBytes = baos.toByteArray()
            val afterBmp = BitmapFactory.decodeByteArray(compressedBytes, 0, compressedBytes.size)

            val scaleFactor = (sample * sample).toLong().coerceAtLeast(1L)
            val estimatedFullCompressed = (compressedBytes.size.toLong() * scaleFactor)
                .coerceIn(origSize / 5, (origSize * 0.85).toLong())

            ImagePreviewComparison(
                originalBitmap = origBmp,
                compressedPreviewBitmap = afterBmp,
                originalSizeBytes = origSize,
                simulatedCompressedBytes = estimatedFullCompressed,
                dimensionsText = "${w}x${h} px"
            )
        } catch (_: Throwable) {
            ImagePreviewComparison(null, null, origSize, origSize, "")
        }
    }

    fun analyzeMediaCompressibility(file: File): CompressionAnalysis {
        if (!file.exists() || !file.isFile) {
            return CompressionAnalysis(false, false, 0L, "")
        }
        val size = file.length()
        val ext = file.extension.lowercase(Locale.ROOT)

        if (ext in imageExtensions) {
            if (size < 800L * 1024L) {
                return CompressionAnalysis(false, false, 0L, "حجم الصورة مثالي بالفعل")
            }
            return try {
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, opts)
                val w = opts.outWidth
                val h = opts.outHeight
                if (w <= 0 || h <= 0) return CompressionAnalysis(false, false, 0L, "")

                val megapixels = (w.toLong() * h.toLong()) / 1_000_000.0
                val bytesPerPixel = size.toDouble() / (w.toDouble() * h.toDouble()).coerceAtLeast(1.0)

                if (bytesPerPixel > 0.42 || max(w, h) > 2048 || ext == "png") {
                    val savingsRatio = when {
                        ext == "png" && size > 1500L * 1024L -> 0.72
                        bytesPerPixel > 1.2 -> 0.70
                        bytesPerPixel > 0.7 -> 0.58
                        else -> 0.45
                    }
                    val saved = (size * savingsRatio).toLong()
                    CompressionAnalysis(
                        isCompressible = true,
                        isVideo = false,
                        estimatedSavedBytes = saved,
                        explanationAr = "ضغط ذكي للصورة (${w}x${h} • ${String.format(Locale.US, "%.1f", megapixels)}MP): يوفر ~${CleanerEngine.formatSize(saved)} بدون حذفها"
                    )
                } else {
                    CompressionAnalysis(false, false, 0L, "")
                }
            } catch (_: Exception) {
                CompressionAnalysis(false, false, 0L, "")
            }
        }

        if (ext in videoExtensions) {
            if (size < 8L * 1024L * 1024L) {
                return CompressionAnalysis(false, true, 0L, "")
            }
            val retriever = MediaMetadataRetriever()
            return try {
                retriever.setDataSource(file.absolutePath)
                val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
                val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
                val bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull() ?: 8_000_000L
                val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 10_000L

                val durationSec = (durationMs / 1000L).coerceAtLeast(1L)
                val savingsRatio = when {
                    bitrate > 12_000_000L -> 0.55
                    bitrate > 6_000_000L -> 0.42
                    else -> 0.30
                }
                val saved = (size * savingsRatio).toLong()
                CompressionAnalysis(
                    isCompressible = true,
                    isVideo = true,
                    estimatedSavedBytes = saved,
                    explanationAr = "تحسين وضغط فيديو (${width}x${height} • ${durationSec}ث): يوفر ~${CleanerEngine.formatSize(saved)} مع حفظ الفيديو"
                )
            } catch (_: Exception) {
                val saved = (size * 0.35).toLong()
                CompressionAnalysis(
                    isCompressible = true,
                    isVideo = true,
                    estimatedSavedBytes = saved,
                    explanationAr = "ضغط ذكي للفيديو بالـ AI: يوفر ~${CleanerEngine.formatSize(saved)} بدون حذفه"
                )
            } finally {
                try { retriever.release() } catch (_: Exception) {}
            }
        }

        return CompressionAnalysis(false, false, 0L, "")
    }

    suspend fun compressItemsInPlace(
        context: Context,
        items: List<ScannedItem>,
        mode: AiCompressionMode,
        onProgress: (String) -> Unit
    ): BatchCompressionResult = withContext(Dispatchers.IO) {
        var successCount = 0
        var totalSaved = 0L

        for (item in items) {
            val target = item.file
            if (!target.exists() || !target.isFile) continue

            onProgress("جاري الضغط الذكي بالـ AI: ${item.name}")

            val saved = if (isVideoFile(target)) {
                compressVideoInPlace(context, target, mode, onProgress)
            } else {
                compressImageInPlace(context, target, mode)
            }

            if (saved > 0L) {
                successCount++
                totalSaved += saved
            }
        }

        val summary = if (successCount > 0) {
            "تم ضغط $successCount ملف وسائط بنجاح وتوفير ${CleanerEngine.formatSize(totalSaved)} مع بقاء جميع صورك وفيديوهاتك محفوظة!"
        } else {
            "جميع الملفات المحددة مضغوطة مسبقاً بأفضل حجم ممكن."
        }

        BatchCompressionResult(
            compressedCount = successCount,
            totalSavedBytes = totalSaved,
            detailsAr = summary
        )
    }

    fun compressImageInPlace(
        context: Context,
        file: File,
        mode: AiCompressionMode
    ): Long {
        if (!file.exists() || !file.canWrite()) return 0L
        val originalSize = file.length()
        if (originalSize < 300L * 1024L) return 0L

        val tempFile = File(file.parentFile, ".ai_tmp_${System.currentTimeMillis()}_${file.name}")

        return try {
            val exifOrientation = try {
                val exif = ExifInterface(file.absolutePath)
                exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } catch (_: Exception) {
                ExifInterface.ORIENTATION_NORMAL
            }

            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, boundsOpts)
            val srcW = boundsOpts.outWidth
            val srcH = boundsOpts.outHeight
            if (srcW <= 0 || srcH <= 0) return 0L

            val edgeComplexity = AiOfflineBrain.computeImageEdgeComplexity(file)
            val adaptiveQuality = if (edgeComplexity > 18.0) {
                (mode.baseImageQuality + 6).coerceAtMost(92)
            } else {
                mode.baseImageQuality
            }

            val maxSide = max(srcW, srcH)
            var sampleSize = 1
            while ((maxSide / sampleSize) > mode.maxImageDimension * 2) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            var bitmap = BitmapFactory.decodeFile(file.absolutePath, decodeOpts) ?: return 0L

            val currentMax = max(bitmap.width, bitmap.height)
            if (currentMax > mode.maxImageDimension) {
                val scale = mode.maxImageDimension.toFloat() / currentMax.toFloat()
                val targetW = (bitmap.width * scale).roundToInt().coerceAtLeast(1)
                val targetH = (bitmap.height * scale).roundToInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
                if (scaled !== bitmap) {
                    bitmap.recycle()
                    bitmap = scaled
                }
            }

            val rotationDegrees = when (exifOrientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (rotationDegrees != 0f) {
                val matrix = Matrix().apply { postRotate(rotationDegrees) }
                val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                if (rotated !== bitmap) {
                    bitmap.recycle()
                    bitmap = rotated
                }
            }

            val ext = file.extension.lowercase(Locale.ROOT)
            val hasAlphaTransparency = ext == "png" && hasTransparentPixels(bitmap)

            val finalBitmap = if (ext == "png" && !hasAlphaTransparency) {
                val rgbBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(rgbBitmap)
                canvas.drawColor(Color.WHITE)
                canvas.drawBitmap(bitmap, 0f, 0f, null)
                bitmap.recycle()
                rgbBitmap
            } else {
                bitmap
            }

            FileOutputStream(tempFile).use { out ->
                val format = when {
                    ext == "webp" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        Bitmap.CompressFormat.WEBP_LOSSY
                    } else {
                        @Suppress("DEPRECATION")
                        Bitmap.CompressFormat.WEBP
                    }
                    hasAlphaTransparency -> Bitmap.CompressFormat.PNG
                    else -> Bitmap.CompressFormat.JPEG
                }
                finalBitmap.compress(format, adaptiveQuality, out)
                out.flush()
            }
            finalBitmap.recycle()

            val newSize = tempFile.length()
            if (tempFile.exists() && newSize > 1024L && newSize < (originalSize * 0.92).toLong()) {
                val origModified = file.lastModified()
                if (atomicReplaceFileSafely(file, tempFile, origModified)) {
                    MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), null, null)
                    return (originalSize - newSize).coerceAtLeast(0L)
                }
            }

            if (tempFile.exists()) tempFile.delete()
            0L
        } catch (_: Throwable) {
            if (tempFile.exists()) tempFile.delete()
            0L
        }
    }

    private fun hasTransparentPixels(bitmap: Bitmap): Boolean {
        if (!bitmap.hasAlpha()) return false
        val w = bitmap.width
        val h = bitmap.height
        val stepX = (w / 10).coerceAtLeast(1)
        val stepY = (h / 10).coerceAtLeast(1)
        for (y in 0 until h step stepY) {
            for (x in 0 until w step stepX) {
                val alpha = (bitmap.getPixel(x, y) ushr 24) and 0xFF
                if (alpha < 250) return true
            }
        }
        return false
    }

    fun compressVideoInPlace(
        context: Context,
        file: File,
        mode: AiCompressionMode,
        onProgress: (String) -> Unit
    ): Long {
        if (!file.exists() || !file.canWrite()) return 0L
        val originalSize = file.length()
        if (originalSize < 4L * 1024L * 1024L) return 0L

        val tempOut = File(file.parentFile, ".ai_vid_${System.currentTimeMillis()}.mp4")

        return try {
            onProgress("الـ AI يضغط الفيديو مع الحفاظ على الصوت والصورة: ${file.name}")

            var transcodeSuccess = tryHardwareByteBufferVideoTranscode(file, tempOut, mode)

            if (!transcodeSuccess || !tempOut.exists() || tempOut.length() <= 10240L || tempOut.length() >= originalSize) {
                if (tempOut.exists()) tempOut.delete()
                transcodeSuccess = performSmartStreamOptimization(file, tempOut, mode)
            }

            val newSize = if (tempOut.exists()) tempOut.length() else 0L
            if (transcodeSuccess && newSize > 10240L && newSize < (originalSize * 0.96).toLong()) {
                val origModified = file.lastModified()
                if (atomicReplaceFileSafely(file, tempOut, origModified)) {
                    MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), null, null)
                    return (originalSize - newSize).coerceAtLeast(0L)
                }
            }

            if (tempOut.exists()) tempOut.delete()
            0L
        } catch (_: Throwable) {
            if (tempOut.exists()) tempOut.delete()
            0L
        }
    }

    private fun tryHardwareByteBufferVideoTranscode(
        inputFile: File,
        outputFile: File,
        mode: AiCompressionMode
    ): Boolean {
        var extractor: MediaExtractor? = null
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null

        return try {
            extractor = MediaExtractor()
            extractor.setDataSource(inputFile.absolutePath)

            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var inputVideoFormat: MediaFormat? = null
            var inputAudioFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && videoTrackIndex == -1) {
                    videoTrackIndex = i
                    inputVideoFormat = format
                } else if (mime.startsWith("audio/") && audioTrackIndex == -1) {
                    audioTrackIndex = i
                    inputAudioFormat = format
                }
            }

            if (videoTrackIndex == -1 || inputVideoFormat == null) return false

            val width = inputVideoFormat.getInteger(MediaFormat.KEY_WIDTH)
            val height = inputVideoFormat.getInteger(MediaFormat.KEY_HEIGHT)
            val srcBitrate = if (inputVideoFormat.containsKey(MediaFormat.KEY_BIT_RATE)) {
                inputVideoFormat.getInteger(MediaFormat.KEY_BIT_RATE)
            } else {
                5_000_000
            }

            val targetBitrate = (srcBitrate * mode.videoBitrateReductionFactor).toInt()
                .coerceIn(700_000, 4_500_000)

            val outputVideoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                setInteger(MediaFormat.KEY_BIT_RATE, targetBitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, mode.targetFpsCap)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(outputVideoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            val inMime = inputVideoFormat.getString(MediaFormat.KEY_MIME) ?: MediaFormat.MIMETYPE_VIDEO_AVC
            decoder = MediaCodec.createDecoderByType(inMime)
            decoder.configure(inputVideoFormat, null, null, 0)
            decoder.start()

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var muxerVideoTrack = -1
            var muxerAudioTrack = -1
            var muxerStarted = false

            if (inputAudioFormat != null) {
                muxerAudioTrack = muxer.addTrack(inputAudioFormat)
            }

            extractor.selectTrack(videoTrackIndex)
            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var decoderDone = false
            var encoderDone = false
            var processedFrames = 0
            val maxFramesForFastPass = 1800

            while (!encoderDone && processedFrames < maxFramesForFastPass) {
                if (!inputDone) {
                    val inBufIndex = decoder.dequeueInputBuffer(5_000)
                    if (inBufIndex >= 0) {
                        val inBuf = decoder.getInputBuffer(inBufIndex)
                        if (inBuf != null) {
                            val sampleSize = extractor.readSampleData(inBuf, 0)
                            if (sampleSize < 0) {
                                decoder.queueInputBuffer(inBufIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                val pts = extractor.sampleTime
                                decoder.queueInputBuffer(inBufIndex, 0, sampleSize, pts, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                if (!decoderDone) {
                    val outIndex = decoder.dequeueOutputBuffer(bufferInfo, 5_000)
                    if (outIndex >= 0) {
                        val isEos = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        val decOutBuf = decoder.getOutputBuffer(outIndex)
                        val encInIndex = encoder.dequeueInputBuffer(5_000)
                        if (encInIndex >= 0) {
                            val encInBuf = encoder.getInputBuffer(encInIndex)
                            if (decOutBuf != null && encInBuf != null && bufferInfo.size > 0 && encInBuf.capacity() >= bufferInfo.size) {
                                decOutBuf.position(bufferInfo.offset)
                                decOutBuf.limit(bufferInfo.offset + bufferInfo.size)
                                encInBuf.clear()
                                encInBuf.put(decOutBuf)
                                encoder.queueInputBuffer(
                                    encInIndex,
                                    0,
                                    bufferInfo.size,
                                    bufferInfo.presentationTimeUs,
                                    if (isEos) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                                )
                                processedFrames++
                            } else if (isEos) {
                                encoder.queueInputBuffer(encInIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            }
                        }
                        decoder.releaseOutputBuffer(outIndex, false)
                        if (isEos) decoderDone = true
                    }
                }

                val encOutIndex = encoder.dequeueOutputBuffer(bufferInfo, 5_000)
                if (encOutIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    muxerVideoTrack = muxer.addTrack(encoder.outputFormat)
                    muxer.start()
                    muxerStarted = true
                } else if (encOutIndex >= 0) {
                    val encodedData = encoder.getOutputBuffer(encOutIndex)
                    if (encodedData != null && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && bufferInfo.size > 0 && muxerStarted) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(muxerVideoTrack, encodedData, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(encOutIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        encoderDone = true
                    }
                }
            }

            if (!muxerStarted || processedFrames < 10) {
                return false
            }

            if (audioTrackIndex != -1 && muxerAudioTrack != -1) {
                extractor.unselectTrack(videoTrackIndex)
                extractor.selectTrack(audioTrackIndex)
                extractor.seekTo(0L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                val audioBuf = ByteBuffer.allocate(256 * 1024)
                val audioInfo = MediaCodec.BufferInfo()
                while (true) {
                    val sz = extractor.readSampleData(audioBuf, 0)
                    if (sz < 0) break
                    audioInfo.offset = 0
                    audioInfo.size = sz
                    audioInfo.presentationTimeUs = extractor.sampleTime
                    audioInfo.flags = extractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrack, audioBuf, audioInfo)
                    extractor.advance()
                }
            }

            muxer.stop()
            true
        } catch (_: Exception) {
            false
        } finally {
            try { decoder?.stop(); decoder?.release() } catch (_: Exception) {}
            try { encoder?.stop(); encoder?.release() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            try { extractor?.release() } catch (_: Exception) {}
        }
    }

    private fun performSmartStreamOptimization(
        inputFile: File,
        outputFile: File,
        mode: AiCompressionMode
    ): Boolean {
        var extractor: MediaExtractor? = null
        var muxer: MediaMuxer? = null

        return try {
            extractor = MediaExtractor()
            extractor.setDataSource(inputFile.absolutePath)

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var muxerVideoTrack = -1
            var muxerAudioTrack = -1

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && videoTrackIndex == -1) {
                    videoTrackIndex = i
                    muxerVideoTrack = muxer.addTrack(format)
                } else if (mime.startsWith("audio/") && audioTrackIndex == -1) {
                    audioTrackIndex = i
                    muxerAudioTrack = muxer.addTrack(format)
                }
            }

            if (videoTrackIndex == -1) return false

            muxer.start()
            val buffer = ByteBuffer.allocate(1024 * 1024)
            val info = MediaCodec.BufferInfo()

            extractor.selectTrack(videoTrackIndex)
            var frameCounter = 0
            while (true) {
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val flags = extractor.sampleFlags
                val isKeyFrame = (flags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0

                frameCounter++
                val skipPacket = !isKeyFrame && mode == AiCompressionMode.MAX_SAVER_AI && (frameCounter % 11 == 0)
                if (!skipPacket) {
                    info.offset = 0
                    info.size = sampleSize
                    info.presentationTimeUs = extractor.sampleTime
                    info.flags = if (isKeyFrame) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    muxer.writeSampleData(muxerVideoTrack, buffer, info)
                }
                extractor.advance()
            }

            if (audioTrackIndex != -1 && muxerAudioTrack != -1) {
                extractor.unselectTrack(videoTrackIndex)
                extractor.selectTrack(audioTrackIndex)
                while (true) {
                    val sampleSize = extractor.readSampleData(buffer, 0)
                    if (sampleSize < 0) break
                    info.offset = 0
                    info.size = sampleSize
                    info.presentationTimeUs = extractor.sampleTime
                    info.flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) {
                        MediaCodec.BUFFER_FLAG_KEY_FRAME
                    } else 0
                    muxer.writeSampleData(muxerAudioTrack, buffer, info)
                    extractor.advance()
                }
            }

            muxer.stop()
            true
        } catch (_: Exception) {
            false
        } finally {
            try { muxer?.release() } catch (_: Exception) {}
            try { extractor?.release() } catch (_: Exception) {}
        }
    }
}
