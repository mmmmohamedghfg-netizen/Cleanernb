package com.smartcleaner.pro

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class QuarantineEntry(
    val id: String,
    val originalName: String,
    val originalPath: String,
    val vaultFilePath: String,
    val sizeBytes: Long,
    val timestampMs: Long
)

/**
 * إدارة الأمان المزدوجة (v6.0 - Audited):
 * الإصلاحات الجذرية المطبقة:
 * 1. تطبيع المسارات (Path Normalization via trimEnd('/')) في قائمة الاستثناءات لضمان تطابق المجلدات المحمية دائماً.
 * 2. قفل متزامن (@Synchronized) على عمليات القراءة والكتابة في سجل الخزنة (JSON Manifest) لمنع حالات السباق (Race Conditions).
 * 3. تنظيف الملفات المؤقتة اليتيمة في الخزنة إذا فشل حذف الأصل أثناء النقل.
 */
object SafetyAndVaultManager {

    private const val PREFS_NAME = "smart_cleaner_safety_prefs"
    private const val KEY_WHITELIST = "whitelist_paths"
    private const val KEY_VAULT_MANIFEST = "quarantine_manifest_json"
    private const val KEY_USE_VAULT = "use_quarantine_vault"
    private const val KEY_AUTO_CLEAN_ENABLED = "auto_clean_scheduled"
    private val vaultLock = Any()

    private fun normalizePath(path: String): String {
        val trimmed = path.trim()
        return if (trimmed.length > 1) trimmed.trimEnd('/') else trimmed
    }

    fun getWhitelistedPaths(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_WHITELIST, emptySet())
            ?.map { normalizePath(it) }
            ?.toSet() ?: emptySet()
    }

    fun addToWhitelist(context: Context, path: String) {
        val normalized = normalizePath(path)
        if (normalized.isEmpty()) return
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val current = getWhitelistedPaths(context).toMutableSet()
        current.add(normalized)
        prefs.edit().putStringSet(KEY_WHITELIST, current).apply()
    }

    fun removeFromWhitelist(context: Context, path: String) {
        val normalized = normalizePath(path)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val current = getWhitelistedPaths(context).toMutableSet()
        current.remove(normalized)
        prefs.edit().putStringSet(KEY_WHITELIST, current).apply()
    }

    fun isPathWhitelisted(path: String, whitelist: Set<String>): Boolean {
        if (whitelist.isEmpty()) return false
        val cleanTarget = normalizePath(path)
        for (protectedPath in whitelist) {
            val cleanProtected = normalizePath(protectedPath)
            if (cleanTarget == cleanProtected || cleanTarget.startsWith("$cleanProtected/")) {
                return true
            }
        }
        return false
    }

    fun isQuarantineEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_USE_VAULT, true)
    }

    fun setQuarantineEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_USE_VAULT, enabled).apply()
    }

    fun isAutoCleanEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_AUTO_CLEAN_ENABLED, false)
    }

    fun setAutoCleanEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_AUTO_CLEAN_ENABLED, enabled).apply()
    }

    private fun getVaultDir(context: Context): File {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        val dir = File(base, ".SmartCleanerVault")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getQuarantineEntries(context: Context): List<QuarantineEntry> = synchronized(vaultLock) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val rawJson = prefs.getString(KEY_VAULT_MANIFEST, "[]") ?: "[]"
        val list = mutableListOf<QuarantineEntry>()
        try {
            val arr = JSONArray(rawJson)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val vaultPath = obj.optString("vaultFilePath")
                if (vaultPath.isNotEmpty() && File(vaultPath).exists()) {
                    list.add(
                        QuarantineEntry(
                            id = obj.optString("id"),
                            originalName = obj.optString("originalName"),
                            originalPath = obj.optString("originalPath"),
                            vaultFilePath = vaultPath,
                            sizeBytes = obj.optLong("sizeBytes"),
                            timestampMs = obj.optLong("timestampMs")
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        list.sortedByDescending { it.timestampMs }
    }

    private fun saveQuarantineEntries(context: Context, entries: List<QuarantineEntry>) = synchronized(vaultLock) {
        val arr = JSONArray()
        for (e in entries) {
            val obj = JSONObject().apply {
                put("id", e.id)
                put("originalName", e.originalName)
                put("originalPath", e.originalPath)
                put("vaultFilePath", e.vaultFilePath)
                put("sizeBytes", e.sizeBytes)
                put("timestampMs", e.timestampMs)
            }
            arr.put(obj)
        }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_VAULT_MANIFEST, arr.toString()).apply()
    }

    fun moveFileToQuarantine(context: Context, target: File, sizeBytes: Long): Boolean = synchronized(vaultLock) {
        if (!target.exists()) return false
        if (target.isDirectory) {
            return CleanerEngine.deleteDirectoryRecursively(target)
        }
        val vaultDir = getVaultDir(context)
        val safeFileName = target.name.replace(Regex("[^a-zA-Z0-9أ-ي._-]"), "_")
        val id = "${System.currentTimeMillis()}_${ kotlin.math.abs(target.absolutePath.hashCode()) }"
        val destFile = File(vaultDir, "${id}_$safeFileName")

        return try {
            val origPath = target.absolutePath
            val origName = target.name
            val moved = target.renameTo(destFile) || run {
                target.copyTo(destFile, overwrite = true)
                val deletedOrig = target.delete()
                if (!deletedOrig && destFile.exists()) {
                    destFile.delete()
                }
                deletedOrig
            }

            if (moved && destFile.exists()) {
                val current = getQuarantineEntries(context).toMutableList()
                current.add(
                    QuarantineEntry(
                        id = id,
                        originalName = origName,
                        originalPath = origPath,
                        vaultFilePath = destFile.absolutePath,
                        sizeBytes = sizeBytes,
                        timestampMs = System.currentTimeMillis()
                    )
                )
                saveQuarantineEntries(context, current)
                true
            } else {
                if (destFile.exists() && target.exists()) {
                    destFile.delete()
                }
                false
            }
        } catch (_: Exception) {
            if (destFile.exists() && target.exists()) {
                try { destFile.delete() } catch (_: Exception) {}
            }
            false
        }
    }

    suspend fun restoreFromQuarantine(context: Context, entry: QuarantineEntry): Boolean =
        withContext(Dispatchers.IO) {
            synchronized(vaultLock) {
                val vaultFile = File(entry.vaultFilePath)
                if (!vaultFile.exists()) return@withContext false
                return@withContext try {
                    val origFile = File(entry.originalPath)
                    origFile.parentFile?.mkdirs()
                    val restored = vaultFile.renameTo(origFile) || run {
                        vaultFile.copyTo(origFile, overwrite = true)
                        vaultFile.delete()
                    }
                    if (restored && origFile.exists()) {
                        val updated = getQuarantineEntries(context).filterNot { it.id == entry.id }
                        saveQuarantineEntries(context, updated)
                        true
                    } else {
                        false
                    }
                } catch (_: Exception) {
                    false
                }
            }
        }

    suspend fun purgeAllQuarantine(context: Context): Long = withContext(Dispatchers.IO) {
        synchronized(vaultLock) {
            val entries = getQuarantineEntries(context)
            var freed = 0L
            for (e in entries) {
                val f = File(e.vaultFilePath)
                if (f.exists()) {
                    val len = f.length()
                    if (f.delete()) freed += len
                }
            }
            saveQuarantineEntries(context, emptyList())
            freed
        }
    }
}
