package com.smartcleaner.pro

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Process
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class RamStatus(
    val totalRamBytes: Long,
    val usedRamBytes: Long,
    val availableRamBytes: Long,
    val usageRatio: Float
)

data class InstalledAppItem(
    val appName: String,
    val packageName: String,
    val apkSizeBytes: Long,
    val cacheBytes: Long,
    val lastTimeUsedMs: Long,
    val daysUnused: Int,
    val sourceApkPath: String
)

/**
 * مدير النظام والرام والتطبيقات المهجورة (v6.0 - Audited)
 * الإصلاحات الجذرية المطبقة:
 * - إرجاع القيمة الحقيقية للذاكرة المحررة (Actual Measured Freed RAM) بدلاً من وضع حد أدنى افتراضي غير دقيق.
 */
object AppAndSystemManager {

    fun getRamStatus(context: Context): RamStatus {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            val total = memInfo.totalMem.coerceAtLeast(1L)
            val avail = memInfo.availMem.coerceAtLeast(0L)
            val used = (total - avail).coerceAtLeast(0L)
            val ratio = (used.toFloat() / total.toFloat()).coerceIn(0f, 1f)
            RamStatus(total, used, avail, ratio)
        } catch (_: Exception) {
            RamStatus(0L, 0L, 0L, 0f)
        }
    }

    suspend fun boostRamAndKillBackground(context: Context): Pair<Int, Long> =
        withContext(Dispatchers.IO) {
            val before = getRamStatus(context)
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pm = context.packageManager
            var killedCount = 0

            try {
                val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                for (app in apps) {
                    if ((app.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                        app.packageName != context.packageName
                    ) {
                        try {
                            am.killBackgroundProcesses(app.packageName)
                            killedCount++
                        } catch (_: Exception) {}
                    }
                }
            } catch (_: Exception) {}

            System.gc()
            Runtime.getRuntime().gc()

            val after = getRamStatus(context)
            val actualFreedRam = (after.availableRamBytes - before.availableRamBytes).coerceAtLeast(0L)
            Pair(killedCount, actualFreedRam)
        }

    fun hasUsageStatsPermission(context: Context): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    fun openUsageAccessSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    suspend fun scanInstalledUserApps(context: Context): List<InstalledAppItem> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val now = System.currentTimeMillis()
            val oneYearAgo = now - (365L * 24L * 60L * 60L * 1000L)

            val usageMap = mutableMapOf<String, Long>()
            if (hasUsageStatsPermission(context)) {
                try {
                    val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                    val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_YEARLY, oneYearAgo, now)
                    stats?.forEach { stat ->
                        val prev = usageMap[stat.packageName] ?: 0L
                        if (stat.lastTimeUsed > prev) {
                            usageMap[stat.packageName] = stat.lastTimeUsed
                        }
                    }
                } catch (_: Exception) {}
            }

            val result = mutableListOf<InstalledAppItem>()
            val apps = try {
                pm.getInstalledApplications(PackageManager.GET_META_DATA)
            } catch (_: Exception) {
                emptyList()
            }

            for (app in apps) {
                val isUserApp = (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                    (app.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                if (!isUserApp || app.packageName == context.packageName) continue

                val label = try {
                    pm.getApplicationLabel(app).toString()
                } catch (_: Exception) {
                    app.packageName
                }

                val apkFile = File(app.sourceDir ?: "")
                val apkSize = if (apkFile.exists()) apkFile.length() else 0L

                var appCacheBytes = 0L
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && hasUsageStatsPermission(context)) {
                    try {
                        val ssm = context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
                        val storageStats = ssm.queryStatsForPackage(
                            app.storageUuid,
                            app.packageName,
                            Process.myUserHandle()
                        )
                        appCacheBytes = storageStats.cacheBytes
                    } catch (_: Exception) {}
                }

                if (appCacheBytes == 0L) {
                    val extCache = File(
                        Environment.getExternalStorageDirectory(),
                        "Android/data/${app.packageName}/cache"
                    )
                    if (extCache.exists() && extCache.canRead()) {
                        appCacheBytes = extCache.walkTopDown().maxDepth(4).filter { it.isFile }.sumOf { it.length() }
                    }
                }

                val lastUsed = usageMap[app.packageName] ?: apkFile.lastModified()
                val daysUnused = if (lastUsed > 0L) {
                    (((now - lastUsed).coerceAtLeast(0L)) / (1000L * 60L * 60L * 24L)).toInt()
                } else 0

                result.add(
                    InstalledAppItem(
                        appName = label,
                        packageName = app.packageName,
                        apkSizeBytes = apkSize,
                        cacheBytes = appCacheBytes,
                        lastTimeUsedMs = lastUsed,
                        daysUnused = daysUnused,
                        sourceApkPath = app.sourceDir ?: ""
                    )
                )
            }

            result.sortedWith(
                compareByDescending<InstalledAppItem> { it.cacheBytes + it.apkSizeBytes }
            )
        }

    suspend fun backupAppApk(app: InstalledAppItem): String? = withContext(Dispatchers.IO) {
        val src = File(app.sourceApkPath)
        if (!src.exists() || !src.canRead()) return@withContext null
        return@withContext try {
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val backupDir = File(downloads, "SmartCleanerBackups")
            if (!backupDir.exists()) backupDir.mkdirs()

            val safeName = app.appName.replace(Regex("[^a-zA-Z0-9أ-ي._-]"), "_")
            val dest = File(backupDir, "${safeName}_${app.packageName}.apk")
            src.copyTo(dest, overwrite = true)
            dest.absolutePath
        } catch (_: Exception) {
            null
        }
    }

    fun openAppSystemSettings(context: Context, packageName: String) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun requestUninstallApp(context: Context, packageName: String) {
        try {
            val intent = Intent(Intent.ACTION_DELETE).apply {
                data = Uri.parse("package:$packageName")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }
}
