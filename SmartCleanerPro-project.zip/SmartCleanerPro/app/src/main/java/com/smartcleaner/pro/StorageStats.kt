package com.smartcleaner.pro

// usedRatio: 0.0..1.0, freeBytes: free space on the device in bytes.
data class StorageStats(
    val usedRatio: Double,
    val freeBytes: Long
)
