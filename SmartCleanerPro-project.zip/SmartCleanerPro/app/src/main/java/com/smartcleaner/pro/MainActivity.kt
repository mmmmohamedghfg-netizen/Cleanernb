package com.smartcleaner.pro

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

// Minimal placeholder screen. Replace with the real UI.
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            text = "Smart Cleaner Pro"
            setPadding(48, 48, 48, 48)
        }
        setContentView(text)
    }
}
