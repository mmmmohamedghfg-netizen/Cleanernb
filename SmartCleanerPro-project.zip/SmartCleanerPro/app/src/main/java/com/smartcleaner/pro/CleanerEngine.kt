package com.smartcleaner.pro

// PLACEHOLDER: only formatSize is implemented. Replace this file with the real engine.
object CleanerEngine {
    fun formatSize(bytes: Long): String {
        val units = listOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unit = 0
        while (value >= 1024.0 && unit < units.lastIndex) {
            value /= 1024.0
            unit++
        }
        return if (unit == 0) "$bytes B" else String.format(java.util.Locale.US, "%.1f %s", value, units[unit])
    }
}
