package com.smartcleaner.pro

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max

data class AiFileEvaluation(
    val safetyScore: Int,
    val aiReasonAr: String,
    val isCorruptedOrZeroEntropy: Boolean = false
)

data class AiStorageInsight(
    val healthScore: Int,
    val headlineAr: String,
    val detailsAr: String,
    val predictedDaysUntilFull: Int,
    val recommendedActionAr: String
)

object AiOfflineBrain {

    private val disposableTokens = listOf(
        "temp", "tmp", "cache", "caches", "thumb", "thumbnails", "trash",
        "recycle", "log", "logs", "crash", "dump", "backup", "bak", "old",
        "copy", "نسخة", "sent", "status", ".statuses", "stickers", "voice notes"
    )

    /**
     * Whole-word style match on a lowercased path. Plain String.contains() made
     * tokens like "log" match "/catalog/" and "old" match "/golden/", which
     * inflated confidence scores for files that are not junk.
     */
    private fun containsToken(path: String, token: String): Boolean {
        var from = 0
        while (true) {
            val idx = path.indexOf(token, from)
            if (idx < 0) return false
            val before = if (idx == 0) ' ' else path[idx - 1]
            val end = idx + token.length
            val after = if (end >= path.length) ' ' else path[end]
            if (before !in 'a'..'z' && after !in 'a'..'z') return true
            from = idx + 1
        }
    }

    private val duplicateRegex = Regex(""".*(\(\d+\)|_copy|-copy|\scopy)\.[a-zA-Z0-9]+$""")

    private fun calculateSafeSampleSize(width: Int, height: Int, targetMaxSide: Int): Int {
        val maxDim = max(width, height)
        var sample = 1
        while (maxDim / (sample * 2) >= targetMaxSide) {
            sample *= 2
        }
        return sample.coerceAtLeast(1)
    }

    fun evaluateFile(file: File, category: CleanCategory): AiFileEvaluation {
        val nameLower = file.name.lowercase(Locale.ROOT)
        val pathLower = file.absolutePath.lowercase(Locale.ROOT)
        val now = System.currentTimeMillis()
        val ageDays = ((now - file.lastModified()).coerceAtLeast(0L)) / (1000L * 60L * 60L * 24L)

        var score = when (category) {
            CleanCategory.RECENTLY_DELETED -> 97.0
            CleanCategory.HIDDEN_USELESS -> 95.0
            CleanCategory.JUNK_TEMP -> 94.0
            CleanCategory.EMPTY_FOLDERS -> 99.0
            CleanCategory.DUPLICATES_AI -> 93.0
            CleanCategory.SIMILAR_PHOTOS_AI -> 89.0
            CleanCategory.SCREENSHOTS_VOICE_AI -> 87.0
            CleanCategory.BAD_IMAGES_AI -> 86.0
            CleanCategory.MESSENGER_RESIDUAL_AI -> 88.0
            CleanCategory.COMPRESSIBLE_MEDIA_AI -> 95.0
            CleanCategory.LARGE_FILES -> 42.0
        }

        val reasons = mutableListOf<String>()

        val stalenessBoost = (1.0 - exp(-ageDays.toDouble() / 45.0)) * 8.0
        score += stalenessBoost
        if (ageDays > 45) {
            reasons.add("قديم منذ $ageDays يوم")
        }

        val matchedTokens = disposableTokens.count { containsToken(pathLower, it) }
        if (matchedTokens > 0) {
            score += (matchedTokens * 3.5).coerceAtMost(10.0)
        }

        if (duplicateRegex.matches(nameLower)) {
            score += 9.0
            reasons.add("نمط اسم مكرر")
        }

        var zeroEntropy = false
        if (file.isFile && file.length() > 128L && category != CleanCategory.COMPRESSIBLE_MEDIA_AI) {
            val entropy = calculateSampleShannonEntropy(file)
            if (entropy < 0.08) {
                score = 98.0
                zeroEntropy = true
                reasons.add("ملف تالف/صفري الإنتروبيا")
            }
        }

        val finalScore = score.toInt().coerceIn(15, 99)

        val defaultReason = when (category) {
            CleanCategory.RECENTLY_DELETED -> "بقايا سلة محذوفات لا يحتاجها النظام"
            CleanCategory.HIDDEN_USELESS -> "ملف مخفي مؤقت يستهلك الذاكرة بصمت"
            CleanCategory.JUNK_TEMP -> "مخلفات مؤقتة آمنة للحذف تماماً"
            CleanCategory.EMPTY_FOLDERS -> "مجلد فارغ لا يحتوي على أي بيانات"
            CleanCategory.DUPLICATES_AI -> "نسخة مكررة متطابقة البصمة (الأصل محفوظ)"
            CleanCategory.SIMILAR_PHOTOS_AI -> "صورة متشابهة بصرياً (تم الاحتفاظ باللقطة الأوضح)"
            CleanCategory.SCREENSHOTS_VOICE_AI -> "لقطة شاشة قديمة أو مقطع صوتي مؤقت"
            CleanCategory.BAD_IMAGES_AI -> "صورة معتمة/مشوشة أو تالفة بصرياً"
            CleanCategory.MESSENGER_RESIDUAL_AI -> "وسائط مرسلة/حالات مؤقتة لتطبيقات الدردشة"
            CleanCategory.COMPRESSIBLE_MEDIA_AI -> "قابلة للضغط الذكي بالـ AI بدون حذف لتوفير المساحة"
            CleanCategory.LARGE_FILES -> "ملف ضخم (راجع أهميته قبل الحذف)"
        }

        val reasonText = if (reasons.isNotEmpty()) {
            "$defaultReason (${reasons.joinToString(" • ")})"
        } else {
            defaultReason
        }

        return AiFileEvaluation(
            safetyScore = finalScore,
            aiReasonAr = "ثقة الذكاء الاصطناعي $finalScore%: $reasonText",
            isCorruptedOrZeroEntropy = zeroEntropy
        )
    }

    fun computePerceptualDHash64(file: File): Long? {
        val ext = file.extension.lowercase(Locale.ROOT)
        if (ext !in setOf("jpg", "jpeg", "png", "webp")) return null
        if (file.length() < 8192L) return null

        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val opts = BitmapFactory.Options().apply {
                inSampleSize = calculateSafeSampleSize(bounds.outWidth, bounds.outHeight, 64)
            }
            val rawBmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return null
            val resized = Bitmap.createScaledBitmap(rawBmp, 9, 8, true)
            if (resized !== rawBmp) rawBmp.recycle()

            val pixels = IntArray(9 * 8)
            resized.getPixels(pixels, 0, 9, 0, 0, 9, 8)
            resized.recycle()

            var hash = 0L
            var bitIndex = 0
            for (row in 0 until 8) {
                val rowOffset = row * 9
                for (col in 0 until 8) {
                    val leftLum = getLuminance(pixels[rowOffset + col])
                    val rightLum = getLuminance(pixels[rowOffset + col + 1])
                    if (leftLum > rightLum) {
                        hash = hash or (1L shl bitIndex)
                    }
                    bitIndex++
                }
            }
            hash
        } catch (e: Throwable) {
            null
        }
    }

    fun hammingDistance64(hash1: Long, hash2: Long): Int {
        return java.lang.Long.bitCount(hash1 xor hash2)
    }

    fun classifyScreenshotOrVoiceNote(file: File): Pair<Boolean, String>? {
        val nameLower = file.name.lowercase(Locale.ROOT)
        val pathLower = file.absolutePath.lowercase(Locale.ROOT)
        val ext = file.extension.lowercase(Locale.ROOT)
        val ageDays = ((System.currentTimeMillis() - file.lastModified()).coerceAtLeast(0L)) / (1000L * 60L * 60L * 24L)

        val isScreenshot = nameLower.startsWith("screenshot") ||
            nameLower.contains("لقطة شاشة") ||
            pathLower.contains("/screenshots/")

        if (isScreenshot && ext in setOf("jpg", "jpeg", "png", "webp") && ageDays >= 7) {
            return Pair(true, "ثقة الـ AI 90%: لقطة شاشة قديمة منذ $ageDays يوم")
        }

        val isVoiceNote = (ext in setOf("opus", "amr", "ogg", "m4a", "aac")) &&
            (pathLower.contains("voice notes") ||
                pathLower.contains("audio") ||
                nameLower.startsWith("ptt-") ||
                nameLower.startsWith("aud-"))

        if (isVoiceNote && file.length() < 10L * 1024L * 1024L && ageDays >= 14) {
            return Pair(true, "ثقة الـ AI 88%: مذكرة صوتية/ريكورد دردشة قديم منذ $ageDays يوم")
        }

        return null
    }

    fun calculateSampleShannonEntropy(file: File): Double {
        return try {
            val sampleSize = minOf(file.length(), 2048L).toInt()
            if (sampleSize <= 0) return 0.0
            val buffer = ByteArray(sampleSize)
            RandomAccessFile(file, "r").use { raf ->
                raf.readFully(buffer)
            }
            val frequencies = IntArray(256)
            for (b in buffer) {
                frequencies[b.toInt() and 0xFF]++
            }
            var entropy = 0.0
            val total = sampleSize.toDouble()
            for (count in frequencies) {
                if (count > 0) {
                    val p = count / total
                    entropy -= p * (ln(p) / ln(2.0))
                }
            }
            entropy
        } catch (e: Exception) {
            4.0
        }
    }

    fun computeFastContentFingerprint(file: File): String? {
        return try {
            val length = file.length()
            if (length <= 0L) return null
            val digest = MessageDigest.getInstance("SHA-256")
            val chunkSize = 4096
            val buffer = ByteArray(chunkSize)

            RandomAccessFile(file, "r").use { raf ->
                val headRead = raf.read(buffer)
                if (headRead > 0) digest.update(buffer, 0, headRead)

                if (length > chunkSize * 2) {
                    raf.seek(length / 2)
                    val midRead = raf.read(buffer)
                    if (midRead > 0) digest.update(buffer, 0, midRead)
                }

                if (length > chunkSize) {
                    raf.seek((length - chunkSize).coerceAtLeast(0L))
                    val tailRead = raf.read(buffer)
                    if (tailRead > 0) digest.update(buffer, 0, tailRead)
                }
            }

            digest.update(length.toString().toByteArray())
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Full-file SHA-256, streamed. computeFastContentFingerprint() only samples
     * head/middle/tail, so two different files of the same size can collide.
     * Confirm duplicates with this before anything is deleted.
     */
    fun computeFullContentSha256(file: File): String? {
        return try {
            if (!file.isFile || file.length() <= 0L) return null
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(64 * 1024)
            file.inputStream().use { input ->
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            null
        }
    }

    fun analyzeImageQualityOffline(file: File): Pair<Boolean, String>? {
        val ext = file.extension.lowercase(Locale.ROOT)
        if (ext !in setOf("jpg", "jpeg", "png", "webp")) return null
        if (file.length() < 4096L) return Pair(true, "صورة تالفة أو فارغة الحجم")

        return try {
            val boundsOptions = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(file.absolutePath, boundsOptions)
            if (boundsOptions.outWidth <= 0 || boundsOptions.outHeight <= 0) {
                return Pair(true, "ملف صورة تالف لا يمكن قراءته")
            }

            val sampleOptions = BitmapFactory.Options().apply {
                inSampleSize = calculateSafeSampleSize(boundsOptions.outWidth, boundsOptions.outHeight, 128)
            }
            val bmp = BitmapFactory.decodeFile(file.absolutePath, sampleOptions)
                ?: return Pair(true, "بيانات الصورة معطوبة")

            val w = bmp.width
            val h = bmp.height
            if (w < 4 || h < 4) {
                bmp.recycle()
                return null
            }

            val pixels = IntArray(w * h)
            bmp.getPixels(pixels, 0, w, 0, 0, w, h)
            bmp.recycle()

            var totalLuminance = 0.0
            var edgeEnergy = 0.0
            var count = 0

            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val idx = y * w + x
                    val lumCenter = getLuminance(pixels[idx])
                    val lumRight = getLuminance(pixels[idx + 1])
                    val lumDown = getLuminance(pixels[idx + w])

                    totalLuminance += lumCenter
                    edgeEnergy += abs(lumCenter - lumRight) + abs(lumCenter - lumDown)
                    count++
                }
            }

            if (count == 0) return null
            val avgLuminance = totalLuminance / count
            val avgEdge = edgeEnergy / count

            when {
                avgLuminance < 14.0 -> Pair(true, "صورة مظلمة/سوداء تماماً بالخطأ (إضاءة ${avgLuminance.toInt()}%)")
                avgLuminance > 248.0 && avgEdge < 3.0 -> Pair(true, "صورة بيضاء فارغة بلا تفاصيل")
                avgEdge < 2.2 -> Pair(true, "صورة مشوشة أو ضبابية تماماً بلا حواف واضحة")
                else -> null
            }
        } catch (e: Throwable) {
            null
        }
    }

    fun computeImageEdgeComplexity(file: File): Double {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return 12.0

            val sampleOptions = BitmapFactory.Options().apply {
                inSampleSize = calculateSafeSampleSize(bounds.outWidth, bounds.outHeight, 128)
            }
            val bmp = BitmapFactory.decodeFile(file.absolutePath, sampleOptions) ?: return 12.0
            val w = bmp.width
            val h = bmp.height
            if (w < 4 || h < 4) {
                bmp.recycle()
                return 12.0
            }
            val pixels = IntArray(w * h)
            bmp.getPixels(pixels, 0, w, 0, 0, w, h)
            bmp.recycle()

            var edgeEnergy = 0.0
            var count = 0
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val idx = y * w + x
                    val c = getLuminance(pixels[idx])
                    val r = getLuminance(pixels[idx + 1])
                    val d = getLuminance(pixels[idx + w])
                    edgeEnergy += abs(c - r) + abs(c - d)
                    count++
                }
            }
            if (count > 0) edgeEnergy / count else 12.0
        } catch (e: Throwable) {
            12.0
        }
    }

    private fun getLuminance(pixel: Int): Double {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return 0.299 * r + 0.587 * g + 0.114 * b
    }

    fun generateStorageInsight(
        stats: StorageStats,
        scannedItems: List<ScannedItem>
    ): AiStorageInsight {
        val usedPercent = (stats.usedRatio * 100).toInt()
        val reclaimableDeleteBytes = scannedItems.filter {
            it.category != CleanCategory.LARGE_FILES && it.category != CleanCategory.COMPRESSIBLE_MEDIA_AI
        }.sumOf { it.sizeBytes }

        val compressibleSavingsBytes = scannedItems.filter {
            it.category == CleanCategory.COMPRESSIBLE_MEDIA_AI
        }.sumOf { it.estimatedCompressionSavingsBytes }

        val totalPotentialGain = reclaimableDeleteBytes + compressibleSavingsBytes

        val now = System.currentTimeMillis()
        val fourteenDaysMs = 14L * 24L * 60L * 60L * 1000L
        val recentJunkBytes = scannedItems.filter {
            it.category != CleanCategory.LARGE_FILES &&
                it.category != CleanCategory.COMPRESSIBLE_MEDIA_AI &&
                (now - it.file.lastModified()) in 0..fourteenDaysMs
        }.sumOf { it.sizeBytes }

        val dailyRateBytes = (recentJunkBytes / 14L).coerceAtLeast(35L * 1024L * 1024L)
        val predictedDays = if (stats.freeBytes > 0) {
            (stats.freeBytes / dailyRateBytes).toInt().coerceIn(1, 365)
        } else 0

        val healthScore = (100 - (usedPercent * 0.65) - (if (totalPotentialGain > 1024L * 1024L * 1024L) 15 else 5))
            .toInt().coerceIn(10, 99)

        val headline = when {
            scannedItems.isEmpty() -> "الذكاء الاصطناعي المحلي جاهز لتحليل وضغط الملفات"
            totalPotentialGain > 500L * 1024L * 1024L ->
                "يمكنك توفير ${CleanerEngine.formatSize(totalPotentialGain)} فوراً (منها ${CleanerEngine.formatSize(compressibleSavingsBytes)} بالضغط الذكي)!"
            totalPotentialGain > 0L ->
                "اكتشف الـ AI إمكانية توفير ${CleanerEngine.formatSize(totalPotentialGain)} بأمان تام"
            else -> "حالة الذاكرة مستقرة ولا توجد تراكمات حرجة"
        }

        val details = if (scannedItems.isNotEmpty()) {
            val dupCount = scannedItems.count { it.category == CleanCategory.DUPLICATES_AI }
            val simCount = scannedItems.count { it.category == CleanCategory.SIMILAR_PHOTOS_AI }
            val compCount = scannedItems.count { it.category == CleanCategory.COMPRESSIBLE_MEDIA_AI }
            "رصد المحرك $dupCount مكرر، و $simCount صور متشابهة (dHash)، و $compCount وسائط قابلة للضغط الذكي."
        } else {
            "اضغط على زر الفحص الذكي لتشغيل خوارزميات dHash والضغط الذكي وتنظيف النظام."
        }

        val recommendation = when {
            predictedDays < 14 -> "تنبيه: قد تمتلئ الذاكرة خلال $predictedDays يوم. استخدم الضغط الذكي والتنظيف الآن."
            else -> "معدل استقرار الذاكرة يكفي لحوالي $predictedDays يوم قبل الحاجة لتفريغ عميق."
        }

        return AiStorageInsight(
            healthScore = healthScore,
            headlineAr = headline,
            detailsAr = details,
            predictedDaysUntilFull = predictedDays,
            recommendedActionAr = recommendation
        )
    }
}
