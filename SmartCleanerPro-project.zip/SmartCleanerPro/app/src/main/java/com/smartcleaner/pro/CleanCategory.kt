package com.smartcleaner.pro

// Categories referenced by AiOfflineBrain.kt. Keep in sync with the real engine.
enum class CleanCategory {
    RECENTLY_DELETED,
    HIDDEN_USELESS,
    JUNK_TEMP,
    EMPTY_FOLDERS,
    DUPLICATES_AI,
    SIMILAR_PHOTOS_AI,
    SCREENSHOTS_VOICE_AI,
    BAD_IMAGES_AI,
    MESSENGER_RESIDUAL_AI,
    COMPRESSIBLE_MEDIA_AI,
    LARGE_FILES
}
