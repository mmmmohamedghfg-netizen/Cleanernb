package com.smartcleaner.pro

import java.io.File

data class ScannedItem(
    val file: File,
    val category: CleanCategory,
    val sizeBytes: Long,
    val estimatedCompressionSavingsBytes: Long = 0L
)
