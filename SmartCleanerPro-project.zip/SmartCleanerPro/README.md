# Smart Cleaner Pro

## Structure
- `app/src/main/java/com/smartcleaner/pro/AiOfflineBrain.kt` : offline heuristics (fixed).
- `CleanCategory.kt`, `StorageStats.kt`, `ScannedItem.kt` : data types the brain depends on.
- `CleanerEngine.kt` : **placeholder**, only `formatSize` is real. Replace with the real engine.
- `MainActivity.kt` : **placeholder** screen.

## Build
- Locally: `./gradlew assembleDebug` (needs JDK 17 and Android SDK).
- GitHub: `.github/workflows/build.yml` builds the APK on every push and uploads it as an artifact.

## Before deleting duplicates
Use `AiOfflineBrain.computeFullContentSha256` to confirm both files are identical. `computeFastContentFingerprint` is only a pre-filter.
